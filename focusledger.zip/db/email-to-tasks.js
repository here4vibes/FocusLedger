'use strict';
/**
 * db/email-to-tasks.js — Named query functions for email-to-tasks feature.
 *
 * Owns: linked_emails (sender addresses verified via login), email_tasks_stash (pending magic-link claims).
 * Does NOT own: task creation logic (routes/email-to-tasks.js), auth (middleware/auth.js).
 */

const { queryWithRetry } = require('../lib/queryWithRetry');

/**
 * Find a user (id + is_pro) by exact email match across users.email + linked_emails.email.
 * Returns null if not found.
 */
async function findUserByEmail(pool, email) {
  const normalized = (email || '').toLowerCase().trim();

  // Check primary email first
  const primary = await queryWithRetry(pool,
    `SELECT u.id, u.email, u.admin_pro_override, u.pro_granted_until,
            s.plan, s.status as sub_status
     FROM users u
     LEFT JOIN app_subscription s ON s.user_id = u.id
     WHERE LOWER(u.email) = $1
     ORDER BY s.created_at DESC
     LIMIT 1`,
    [normalized]
  );
  if (primary.rows.length) return primary.rows[0];

  // Fall through to linked_emails
  const linked = await queryWithRetry(pool,
    `SELECT u.id, u.email, u.admin_pro_override, u.pro_granted_until,
            s.plan, s.status as sub_status
     FROM linked_emails le
     JOIN users u ON u.id = le.user_id
     LEFT JOIN app_subscription s ON s.user_id = u.id
     WHERE LOWER(le.email) = $1
     ORDER BY s.created_at DESC
     LIMIT 1`,
    [normalized]
  );
  return linked.rows[0] || null;
}

/**
 * Add a linked email for a user (max 5 per user enforced here).
 * Returns { added: true } if inserted, { added: false } if already exists or limit reached.
 */
async function addLinkedEmail(pool, userId, email) {
  const normalized = (email || '').toLowerCase().trim();

  // Count existing linked emails
  const countResult = await queryWithRetry(pool,
    'SELECT COUNT(*) as count FROM linked_emails WHERE user_id = $1',
    [userId]
  );
  if (parseInt(countResult.rows[0].count, 10) >= 5) {
    return { added: false, reason: 'max_linked_emails' };
  }

  const result = await queryWithRetry(pool,
    `INSERT INTO linked_emails (user_id, email, verified_at)
     VALUES ($1, $2, NOW())
     ON CONFLICT (user_id, email) DO NOTHING
     RETURNING id`,
    [userId, normalized]
  );
  return { added: result.rows.length > 0 };
}

/**
 * Stash an inbound email from an unknown sender with a unique token.
 * Returns the created row.
 */
async function stashEmail(pool, { fromEmail, subject, bodyText, bodyHtml, messageId, token }) {
  const result = await queryWithRetry(pool,
    `INSERT INTO email_tasks_stash (token, from_email, subject, body_text, body_html, message_id)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *`,
    [token, (fromEmail || '').toLowerCase().trim(), subject || null, bodyText || null, bodyHtml || null, messageId || null]
  );
  return result.rows[0];
}

/**
 * Find a stash entry by token. Returns null if not found, expired, or already claimed.
 */
async function findStashByToken(pool, token) {
  const result = await queryWithRetry(pool,
    `SELECT * FROM email_tasks_stash
     WHERE token = $1
       AND claimed_at IS NULL
       AND expires_at > NOW()`,
    [token]
  );
  return result.rows[0] || null;
}

/**
 * Mark a stash entry as claimed.
 */
async function claimStash(pool, token) {
  await queryWithRetry(pool,
    'UPDATE email_tasks_stash SET claimed_at = NOW() WHERE token = $1',
    [token]
  );
}

/**
 * Delete expired unclaimed stash entries (called by cleanup cron).
 * Returns count of deleted rows.
 */
async function purgeExpiredStash(pool) {
  const result = await queryWithRetry(pool,
    'DELETE FROM email_tasks_stash WHERE expires_at <= NOW() AND claimed_at IS NULL RETURNING id',
    []
  );
  return result.rows.length;
}

/**
 * Insert a task for a user from an email. Returns the created task row.
 * subject is used as title; body_text as notes (trimmed to 2000 chars).
 * WHY: we keep this in db/ to centralize all direct pool queries for the feature.
 */
async function insertEmailTask(pool, { userId, title, notes }) {
  const safeTitle = (title || 'Email task (no subject)').slice(0, 150);
  const safeNotes = notes ? notes.slice(0, 2000) : null;

  const result = await queryWithRetry(pool,
    `INSERT INTO tasks (user_id, title, notes, created_at, updated_at)
     VALUES ($1, $2, $3, NOW(), NOW())
     RETURNING *`,
    [userId, safeTitle, safeNotes]
  );
  return result.rows[0];
}

/**
 * Check for duplicate by message-id to prevent task creation from re-delivered emails.
 * Returns true if a stash entry (claimed or unclaimed) or a task creation from this message_id exists.
 * WHY: we use email_tasks_stash as the dedup store for the webhook path; tasks table has no message_id.
 */
async function isMessageDuplicate(pool, messageId) {
  if (!messageId) return false;
  const result = await queryWithRetry(pool,
    'SELECT 1 FROM email_tasks_stash WHERE message_id = $1 LIMIT 1',
    [messageId]
  );
  return result.rows.length > 0;
}

/**
 * List linked emails for a user.
 */
async function listLinkedEmails(pool, userId) {
  const result = await queryWithRetry(pool,
    'SELECT id, email, verified_at, created_at FROM linked_emails WHERE user_id = $1 ORDER BY created_at DESC',
    [userId]
  );
  return result.rows;
}

/**
 * Remove a linked email by id (scoped to user_id for safety).
 */
async function removeLinkedEmail(pool, id, userId) {
  await queryWithRetry(pool,
    'DELETE FROM linked_emails WHERE id = $1 AND user_id = $2',
    [id, userId]
  );
}

module.exports = {
  findUserByEmail,
  addLinkedEmail,
  listLinkedEmails,
  removeLinkedEmail,
  stashEmail,
  findStashByToken,
  claimStash,
  purgeExpiredStash,
  insertEmailTask,
  isMessageDuplicate,
};
