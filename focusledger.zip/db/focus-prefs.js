'use strict';
/**
 * db/focus-prefs.js — Named query functions for user_focus_prefs table.
 *
 * Owns: user_focus_prefs
 * Does NOT own: focus_sessions
 */

const { queryWithRetry } = require('../lib/queryWithRetry');

const VALID_STYLES = new Set(['cafe', 'library', 'rain', 'audio_only']);
const VALID_INTERVALS = new Set([45, 60, 90, 120]);

/**
 * Get focus preferences for a user. Returns defaults if row doesn't exist.
 */
async function getFocusPrefs(pool, userId) {
  const result = await queryWithRetry(pool, `
    SELECT body_double_enabled, ambient_style, ambient_volume, break_interval_minutes, updated_at
    FROM user_focus_prefs
    WHERE user_id = $1
  `, [userId]);

  if (result.rows.length === 0) {
    return {
      body_double_enabled: false,
      ambient_style: 'cafe',
      ambient_volume: 30,
      break_interval_minutes: 90,
      updated_at: null,
    };
  }
  return result.rows[0];
}

/**
 * Upsert focus preferences. Partial updates supported — only provided
 * fields are written; omitted fields are left unchanged.
 */
async function upsertFocusPrefs(pool, userId, { bodyDoubleEnabled, ambientStyle, ambientVolume, breakIntervalMinutes } = {}) {
  const sets = [];
  const vals = [userId];
  let i = 2;

  if (bodyDoubleEnabled !== undefined) {
    sets.push(`body_double_enabled = $${i++}`);
    vals.push(bodyDoubleEnabled);
  }
  if (ambientStyle !== undefined) {
    if (!VALID_STYLES.has(ambientStyle)) ambientStyle = 'cafe';
    sets.push(`ambient_style = $${i++}`);
    vals.push(ambientStyle);
  }
  if (ambientVolume !== undefined) {
    const vol = Math.max(0, Math.min(100, parseInt(ambientVolume, 10) || 30));
    sets.push(`ambient_volume = $${i++}`);
    vals.push(vol);
  }
  if (breakIntervalMinutes !== undefined) {
    const interval = VALID_INTERVALS.has(parseInt(breakIntervalMinutes, 10)) ? parseInt(breakIntervalMinutes, 10) : 90;
    sets.push(`break_interval_minutes = $${i++}`);
    vals.push(interval);
  }

  if (sets.length === 0) return getFocusPrefs(pool, userId);

  sets.push('updated_at = now()');

  const result = await queryWithRetry(pool, `
    INSERT INTO user_focus_prefs (user_id, body_double_enabled, ambient_style, ambient_volume, break_interval_minutes, updated_at)
    VALUES ($1, COALESCE($2, false), COALESCE($3, 'cafe'), COALESCE($4, 30), COALESCE($5, 90), now())
    ON CONFLICT (user_id) DO UPDATE SET
      ${sets.join(', ')}
    RETURNING body_double_enabled, ambient_style, ambient_volume, break_interval_minutes, updated_at
  `, vals);

  return result.rows[0];
}

module.exports = {
  getFocusPrefs,
  upsertFocusPrefs,
};