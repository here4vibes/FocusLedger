'use strict';
/**
 * db/focus-sessions.js — Named query functions for focus_sessions table.
 *
 * Owns: focus_sessions
 * Does NOT own: tasks (see routes/tasks.js)
 */

const { queryWithRetry } = require('../lib/queryWithRetry');

/**
 * Create a new focus session row.
 * Returns the session row with id.
 */
async function createSession(pool, { userId, taskId, plannedDurationSeconds }) {
  const result = await queryWithRetry(pool, `
    INSERT INTO focus_sessions (user_id, task_id, planned_duration_seconds)
    VALUES ($1, $2, $3)
    RETURNING id, user_id, task_id, planned_duration_seconds, started_at
  `, [userId, taskId, plannedDurationSeconds]);
  return result.rows[0];
}

/**
 * Get a focus session by ID and user (ownership check).
 */
async function getSessionById(pool, { sessionId, userId }) {
  const result = await queryWithRetry(pool, `
    SELECT id, user_id, task_id, planned_duration_seconds, actual_duration_seconds,
           completed, started_at, ended_at
    FROM focus_sessions
    WHERE id = $1 AND user_id = $2
  `, [sessionId, userId]);
  return result.rows[0] || null;
}

/**
 * Complete a focus session: set actual_duration_seconds, completed flag, ended_at.
 */
async function completeSession(pool, { sessionId, userId, actualDurationSeconds, completed }) {
  const result = await queryWithRetry(pool, `
    UPDATE focus_sessions
    SET actual_duration_seconds = $3,
        completed = $4,
        ended_at = now()
    WHERE id = $1 AND user_id = $2
    RETURNING id, completed, actual_duration_seconds, ended_at
  `, [sessionId, userId, actualDurationSeconds, completed]);
  return result.rows[0] || null;
}

/**
 * Get the last N focus sessions for a user (for stats display).
 */
async function getRecentSessions(pool, userId, limit = 10) {
  const result = await queryWithRetry(pool, `
    SELECT fs.id, fs.task_id, fs.planned_duration_seconds, fs.actual_duration_seconds,
           fs.completed, fs.started_at, fs.ended_at,
           t.title as task_title
    FROM focus_sessions fs
    LEFT JOIN tasks t ON t.id = fs.task_id
    WHERE fs.user_id = $1
    ORDER BY fs.started_at DESC
    LIMIT $2
  `, [userId, limit]);
  return result.rows;
}

module.exports = {
  createSession,
  getSessionById,
  completeSession,
  getRecentSessions,
};