'use strict';
/**
 * Follow-up email queries
 *
 * Manages: followup_email_types, user_followup_prefs, followup_email_log
 * No raw SQL outside this file.
 */

// ── followup_email_types ──────────────────────────────────────────────────────

/** Get all active email types in display order. */
async function getEmailTypes(pool) {
  const { rows } = await pool.query(
    `SELECT id, label, description, default_enabled, default_hour
     FROM followup_email_types WHERE is_active = true ORDER BY id`
  );
  return rows;
}

// ── user_followup_prefs ──────────────────────────────────────────────────────

/** Get prefs for a user (returns defaults if no row). */
async function getUserPrefs(pool, userId) {
  const { rows } = await pool.query(
    `SELECT task_reminder, task_reminder_hour,
            routine_streak, routine_streak_hour,
            weekly_summary, weekly_summary_hour,
            follow_through, follow_through_hour
     FROM user_followup_prefs WHERE user_id = $1`,
    [userId]
  );
  if (rows.length === 0) return null;

  const p = rows[0];
  return {
    task_reminder: p.task_reminder,
    task_reminder_hour: p.task_reminder_hour,
    routine_streak: p.routine_streak,
    routine_streak_hour: p.routine_streak_hour,
    weekly_summary: p.weekly_summary,
    weekly_summary_hour: p.weekly_summary_hour,
    follow_through: p.follow_through,
    follow_through_hour: p.follow_through_hour,
  };
}

/**
 * Upsert user prefs. All fields required to avoid partial writes.
 * Pass the full set of current values to make the update atomic.
 */
async function upsertUserPrefs(pool, userId, prefs) {
  const {
    task_reminder, task_reminder_hour,
    routine_streak, routine_streak_hour,
    weekly_summary, weekly_summary_hour,
    follow_through, follow_through_hour,
  } = prefs;

  await pool.query(
    `INSERT INTO user_followup_prefs
       (user_id, task_reminder, task_reminder_hour,
        routine_streak, routine_streak_hour,
        weekly_summary, weekly_summary_hour,
        follow_through, follow_through_hour)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (user_id) DO UPDATE SET
       task_reminder      = EXCLUDED.task_reminder,
       task_reminder_hour = EXCLUDED.task_reminder_hour,
       routine_streak     = EXCLUDED.routine_streak,
       routine_streak_hour= EXCLUDED.routine_streak_hour,
       weekly_summary     = EXCLUDED.weekly_summary,
       weekly_summary_hour= EXCLUDED.weekly_summary_hour,
       follow_through     = EXCLUDED.follow_through,
       follow_through_hour= EXCLUDED.follow_through_hour,
       updated_at         = NOW()`,
    [userId, task_reminder, task_reminder_hour,
          routine_streak, routine_streak_hour,
          weekly_summary, weekly_summary_hour,
          follow_through, follow_through_hour]
  );
}

/**
 * Get all Pro users with their current prefs (or defaults) + timezone.
 * Used by the cron job to evaluate who gets which email.
 */
async function getProUsersWithPrefs(pool) {
  const { rows } = await pool.query(`
    SELECT
      u.id,
      u.email,
      u.name,
      COALESCE(NULLIF(u.timezone, ''), 'America/New_York') AS timezone,
      p.task_reminder,   p.task_reminder_hour,
      p.routine_streak,  p.routine_streak_hour,
      p.weekly_summary,  p.weekly_summary_hour,
      p.follow_through,  p.follow_through_hour
    FROM users u
    JOIN app_subscription s ON s.user_id = u.id
    LEFT JOIN user_followup_prefs p ON p.user_id = u.id
    WHERE s.plan = 'pro'
      AND s.status = 'active'
      AND COALESCE(u.is_qa_user, false) = false
  `);

  // Fill defaults where prefs row is absent
  return rows.map(row => {
    const hasPrefs = row.task_reminder !== null;
    if (!hasPrefs) {
      row.task_reminder      = true;  row.task_reminder_hour   = 8;
      row.routine_streak     = true;  row.routine_streak_hour  = 9;
      row.weekly_summary     = true;  row.weekly_summary_hour  = 8;
      row.follow_through     = true;  row.follow_through_hour  = 10;
    }
    return row;
  });
}

// ── followup_email_log ────────────────────────────────────────────────────────

/**
 * Check if an email was already sent today for this trigger.
 * Returns true if a row exists for the same user+type+triggerRef today.
 */
async function alreadySentToday(pool, userId, emailType, triggerRef) {
  const { rows } = await pool.query(
    `SELECT id FROM followup_email_log
     WHERE user_id = $1 AND email_type = $2 AND trigger_ref = $3
       AND sent_at::date = CURRENT_DATE`,
    [userId, emailType, triggerRef]
  );
  return rows.length > 0;
}

/**
 * Check if an email was already sent this week for weekly_summary.
 * Week key format: '2026-05-18' (Monday of current ISO week).
 */
async function alreadySentThisWeek(pool, userId, emailType, weekKey) {
  const { rows } = await pool.query(
    `SELECT id FROM followup_email_log
     WHERE user_id = $1 AND email_type = $2 AND trigger_ref = $3
       AND sent_at >= $4::date
       AND sent_at < ($4::date + INTERVAL '7 days')`,
    [userId, emailType, weekKey, weekKey]
  );
  return rows.length > 0;
}

/**
 * Log a sent follow-up email.
 * Returns the new log id (for potential tracking pixel use, though this is one-way outbound).
 */
async function logSent(pool, { userId, emailType, triggerRef, triggerLabel, subject }) {
  const { rows } = await pool.query(
    `INSERT INTO followup_email_log (user_id, email_type, trigger_ref, trigger_label, subject)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id`,
    [userId, emailType, triggerRef, triggerLabel, subject]
  );
  return rows[0]?.id || null;
}

/**
 * Get recent follow-up emails for a user's preference page.
 * Returns last 30 days of log entries.
 */
async function getRecentLogs(pool, userId, limit = 50) {
  const { rows } = await pool.query(
    `SELECT id, email_type, trigger_ref, trigger_label, subject, sent_at
     FROM followup_email_log
     WHERE user_id = $1
       AND sent_at >= NOW() - INTERVAL '30 days'
     ORDER BY sent_at DESC
     LIMIT $2`,
    [userId, limit]
  );
  return rows;
}

// ── Task reminder queries ──────────────────────────────────────────────────────

/**
 * Find tasks due today or tomorrow that haven't been completed.
 * Used for task_reminder and follow_through emails.
 * Excludes tasks created from email (those are already tracked separately).
 */
async function getIncompleteTasksDue(pool, userId, dateStr) {
  const { rows } = await pool.query(
    `SELECT id, title, due_date, source
     FROM tasks
     WHERE user_id = $1
       AND completed = false
       AND due_date = $2
       AND source != 'email'
     ORDER BY due_date ASC`,
    [userId, dateStr]
  );
  return rows;
}

// ── Routine streak queries ────────────────────────────────────────────────────

/**
 * Get active routines with streak ≥ minStreak that haven't been nudged today.
 */
async function getActiveStreakRoutines(pool, userId, minStreak) {
  const { rows } = await pool.query(
    `SELECT
       r.id AS routine_id,
       r.name AS routine_name,
       rs.current_streak,
       rs.best_streak,
       rs.last_completed_date,
       fet.default_hour AS default_hour,
       ufp.routine_streak_hour
     FROM routines r
     JOIN routine_streaks rs ON rs.routine_id = r.id
     LEFT JOIN followup_email_types fet ON fet.id = 'routine_streak'
     LEFT JOIN user_followup_prefs ufp ON ufp.user_id = r.user_id
     WHERE r.user_id = $1
       AND r.is_active = true
       AND rs.current_streak >= $2
       -- No log entry today for this routine
       AND NOT EXISTS (
         SELECT 1 FROM followup_email_log l
         WHERE l.user_id = r.user_id
           AND l.email_type = 'routine_streak'
           AND l.trigger_ref = r.id::TEXT
           AND l.sent_at::date = CURRENT_DATE
       )
     ORDER BY rs.current_streak DESC`,
    [userId, minStreak]
  );
  return rows;
}

// ── Weekly summary queries ─────────────────────────────────────────────────────

/**
 * Get weekly stats for a user's summary email.
 * weekStart: 'YYYY-MM-DD' Monday of the week.
 */
async function getWeeklyStats(pool, userId, weekStart) {
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekEnd.getDate() + 6);
  const weekEndStr = weekEnd.toISOString().split('T')[0];

  const { rows } = await pool.query(
    `SELECT
       COUNT(CASE WHEN due_date >= $2 AND due_date <= $3 THEN 1 END) AS tasks_due,
       COUNT(CASE WHEN completed = true
                  AND updated_at >= $2::timestamptz
                  AND updated_at < ($2::timestamptz + INTERVAL '7 days')
                  THEN 1 END) AS tasks_completed,
       COUNT(CASE WHEN completed = true
                  AND due_date >= $2 AND due_date <= $3
                  AND updated_at >= $2::timestamptz
                  AND updated_at < ($2::timestamptz + INTERVAL '7 days')
                  THEN 1 END) AS on_time_completions
     FROM tasks
     WHERE user_id = $1`,
    [userId, weekStart, weekEndStr]
  );

  return rows[0] || { tasks_due: 0, tasks_completed: 0, on_time_completions: 0 };
}

// ── Follow-through: tasks that are 1 day past due ─────────────────────────────

/**
 * Tasks that were due yesterday and are still incomplete.
 * Used for follow_through emails.
 * Only sends once per task.
 */
async function getPastDueTasks(pool, userId, yesterdayStr) {
  const { rows } = await pool.query(
    `SELECT id, title, due_date
     FROM tasks
     WHERE user_id = $1
       AND completed = false
       AND due_date = $2
       AND source != 'email'
     ORDER BY due_date ASC`,
    [userId, yesterdayStr]
  );
  return rows;
}

// ── Check follow-through already sent for a task ──────────────────────────────

/**
 * Was follow_through already sent for this task?
 */
async function followThroughSent(pool, userId, taskId) {
  const { rows } = await pool.query(
    `SELECT id FROM followup_email_log
     WHERE user_id = $1 AND email_type = 'follow_through' AND trigger_ref = $2
       AND sent_at >= (CURRENT_DATE - INTERVAL '1 day')::date`,
    [userId, String(taskId)]
  );
  return rows.length > 0;
}

module.exports = {
  getEmailTypes,
  getUserPrefs,
  upsertUserPrefs,
  getProUsersWithPrefs,
  alreadySentToday,
  alreadySentThisWeek,
  logSent,
  getRecentLogs,
  getIncompleteTasksDue,
  getActiveStreakRoutines,
  getWeeklyStats,
  getPastDueTasks,
  followThroughSent,
};