'use strict';
/**
 * db/waitlist.js — Named query functions for iOS waitlist email capture.
 *
 * Owns: ios_waitlist table (email, source, created_at).
 * Does NOT own: email delivery, subscription logic, auth.
 */

const { queryWithRetry } = require('../lib/queryWithRetry');

/**
 * Add an email to the iOS waitlist.
 * Returns { added: true } on new insert, { added: false, alreadyExists: true } on duplicate.
 */
async function addToWaitlist(pool, email, source) {
  const normalized = (email || '').toLowerCase().trim();
  const result = await queryWithRetry(pool,
    `INSERT INTO ios_waitlist (email, source)
     VALUES ($1, $2)
     ON CONFLICT (email) DO NOTHING
     RETURNING id`,
    [normalized, source || 'ios_waitlist']
  );
  if (result.rows.length > 0) {
    return { added: true };
  }
  return { added: false, alreadyExists: true };
}

/**
 * Count total waitlist entries (for admin visibility).
 */
async function getWaitlistCount(pool) {
  const result = await queryWithRetry(pool, 'SELECT COUNT(*)::int AS count FROM ios_waitlist');
  return result.rows[0].count;
}

module.exports = { addToWaitlist, getWaitlistCount };
