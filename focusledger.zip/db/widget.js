// db/widget.js — named query functions for the iOS widget API.
// Owns: read-only task queries for the home screen widget (top 3 today's tasks).
// Does NOT own: task mutation, task creation, or any write operations (db/tasks.js does).

/**
 * Returns up to 3 incomplete tasks relevant to the user's "today":
 *   1. Overdue (past due_date, not completed)
 *   2. Due today
 *   3. Created today with no due date (not completed)
 *
 * WHY timezone parameter: Neon runs UTC; CURRENT_DATE returns the wrong calendar
 * date for users in non-UTC timezones. We pass localToday computed from the user's
 * stored timezone so the widget shows the same "today" as the main app.
 *
 * @param {Pool} pool - pg Pool instance
 * @param {number} userId
 * @param {string} localToday - "YYYY-MM-DD" in the user's local timezone
 * @param {string} tz - IANA timezone string (e.g. "America/New_York")
 * @returns {Promise<Array>} Array of { id, title, is_completed, due_date, due_time }
 */
async function getTodayWidgetTasks(pool, userId, localToday, tz) {
  const result = await pool.query(
    `SELECT id, title, is_completed, due_date, due_time
     FROM tasks
     WHERE user_id = $1
       AND is_completed = false
       AND (
         due_date < $2                                                         -- overdue
         OR due_date = $2                                                      -- due today
         OR (due_date IS NULL AND (created_at AT TIME ZONE $3)::date = $2::date)  -- created today, no due date
       )
     ORDER BY
       CASE WHEN due_date < $2 THEN 0        -- overdue first
            WHEN due_date = $2 THEN 1         -- then due today
            ELSE 2                             -- then created today
       END ASC,
       due_time ASC NULLS LAST,
       created_at ASC
     LIMIT 3`,
    [userId, localToday, tz]
  );
  return result.rows;
}

module.exports = { getTodayWidgetTasks };
