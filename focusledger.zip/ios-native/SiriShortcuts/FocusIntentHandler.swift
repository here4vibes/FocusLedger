// FocusIntentHandler.swift
// Handles the "What's my focus today?" Siri voice invocation.
// Drop into App/App/ in your Xcode project.
//
// This file owns:
//   - Handling the NSUserActivity continuation for the focus-today activity type
//   - Fetching tasks from the backend API (/api/siri/today-focus)
//   - Reading the spoken_text response aloud via Siri
// This file does NOT own:
//   - Shortcut donation (see FocusLedgerSiriPlugin.swift)
//   - Auth token generation (auth happens in the web layer; token is read from Keychain)

import UIKit
import Intents

// MARK: - AppDelegate continuation hook
// In AppDelegate.swift, add this inside application(_:continue:restorationHandler:):
//
//   if activity.activityType == "net.focusledger.app.focus-today" {
//       FocusIntentHandler.shared.handleFocusActivity(activity, in: window)
//       return true
//   }
//   if activity.activityType == "net.focusledger.app.add-task" {
//       // Navigate to task creation — adjust to your Capacitor bridge call
//       window?.rootViewController?.loadView() // or post a notification
//       return true
//   }

class FocusIntentHandler {
  static let shared = FocusIntentHandler()
  private init() {}

  // Called when Siri invokes "What's my focus today?".
  // Fetches /api/siri/today-focus and reads the response aloud.
  func handleFocusActivity(_ activity: NSUserActivity, in window: UIWindow?) {
    guard let token = KeychainHelper.shared.readJWT() else {
      speakText("Please open FocusLedger and sign in first.")
      return
    }

    fetchTodayFocus(token: token) { result in
      DispatchQueue.main.async {
        switch result {
        case .success(let spokenText):
          self.speakText(spokenText)
        case .failure:
          self.speakText("I couldn't reach FocusLedger right now. Try opening the app.")
        }
      }
    }
  }

  // MARK: - Private

  private func fetchTodayFocus(token: String, completion: @escaping (Result<String, Error>) -> Void) {
    guard let url = URL(string: "https://focusledger.polsia.app/api/siri/today-focus") else {
      completion(.failure(URLError(.badURL)))
      return
    }

    var request = URLRequest(url: url, timeoutInterval: 8)
    request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    URLSession.shared.dataTask(with: request) { data, response, error in
      if let error = error {
        completion(.failure(error))
        return
      }

      guard let data = data,
            let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let spokenText = json["spoken_text"] as? String else {
        completion(.failure(URLError(.cannotParseResponse)))
        return
      }

      completion(.success(spokenText))
    }.resume()
  }

  // WHY AVSpeechSynthesizer: SiriKit's official speech API requires a dedicated App Extension
  // (complex setup). For v1, AVSpeechSynthesizer is simpler and works from the main app target.
  // Upgrade to a proper SiriKit extension in v2 if you want Siri's native voice.
  private func speakText(_ text: String) {
    let utterance = AVSpeechUtterance(string: text)
    utterance.rate = 0.5
    utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
    let synthesizer = AVSpeechSynthesizer()
    synthesizer.speak(utterance)
  }
}

// Import needed for AVSpeechSynthesizer
import AVFoundation
