// FocusLedgerSiriPlugin.m
// Capacitor plugin registration — Objective-C bridge required by Capacitor 5+.
// Drop this file into your Xcode project alongside FocusLedgerSiriPlugin.swift.
//
// This file owns: CAP_PLUGIN macro registration only.
// No logic lives here — all implementation is in the .swift file.

#import <Capacitor/Capacitor.h>

CAP_PLUGIN(FocusLedgerSiriPlugin, "FocusLedgerSiri",
  CAP_PLUGIN_METHOD(donateFocusShortcut, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(donateAddTaskShortcut, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(storeJWT, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(clearJWT, CAPPluginReturnPromise);
)
