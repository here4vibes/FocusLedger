// FocusLedgerSiriPlugin.swift
// Capacitor plugin that bridges JS → native SiriKit shortcut donation.
// Drop this file into your Xcode project under App/App/.
//
// This file owns:
//   - Registering the Capacitor plugin with the bridge
//   - Donating INShortcut objects when called from JS
// This file does NOT own:
//   - The actual Siri intent handling (see FocusLedgerIntentHandler.swift)
//   - Auth token storage (see KeychainHelper.swift)
//   - Backend fetch (the native intent extension handles that separately)

import Capacitor
import Intents

@objc(FocusLedgerSiriPlugin)
public class FocusLedgerSiriPlugin: CAPPlugin {

  // Called from JS: siri-shortcuts.js → donateCheckinShortcut()
  // Donates "What's my focus today?" so iOS can proactively suggest it.
  @objc func donateFocusShortcut(_ call: CAPPluginCall) {
    guard #available(iOS 12.0, *) else {
      call.resolve()
      return
    }

    let activity = NSUserActivity(activityType: "net.focusledger.app.focus-today")
    activity.title = call.getString("title") ?? "What's my focus today?"
    activity.isEligibleForSearch = true
    activity.isEligibleForPrediction = true
    activity.suggestedInvocationPhrase = call.getString("invocationPhrase") ?? "What's my focus today"

    // Persist the activity so SiriKit can associate it with the invocation phrase.
    // WHY: Without setting this on a UIViewController, the donation is ephemeral.
    // We stash it on the plugin bridge's viewController instead.
    DispatchQueue.main.async {
      self.bridge?.viewController?.userActivity = activity
      activity.becomeCurrent()
    }

    // Also donate an explicit shortcut so it appears in the Shortcuts app.
    let shortcut = INShortcut(userActivity: activity)
    let interaction = INInteraction(intent: INIntent(), response: nil)
    _ = interaction // avoid unused warning

    INVoiceShortcutCenter.shared.setShortcutSuggestions([shortcut])

    call.resolve()
  }

  // Called from JS: siri-shortcuts.js → donateAddTaskShortcut()
  // Donates "Add a task" shortcut — opens the app directly to task creation.
  @objc func donateAddTaskShortcut(_ call: CAPPluginCall) {
    guard #available(iOS 12.0, *) else {
      call.resolve()
      return
    }

    let activity = NSUserActivity(activityType: "net.focusledger.app.add-task")
    activity.title = call.getString("title") ?? "Add a task to FocusLedger"
    activity.isEligibleForSearch = true
    activity.isEligibleForPrediction = true
    activity.suggestedInvocationPhrase = call.getString("invocationPhrase") ?? "Add a task to FocusLedger"

    // The deepLink URL is handled in AppDelegate.swift → application(_:continue:restorationHandler:)
    // where we navigate to the task creation sheet.
    activity.userInfo = ["deepLink": "focusledger://tasks/new"]

    DispatchQueue.main.async {
      self.bridge?.viewController?.userActivity = activity
      activity.becomeCurrent()
    }

    let shortcut = INShortcut(userActivity: activity)
    INVoiceShortcutCenter.shared.setShortcutSuggestions(
      INVoiceShortcutCenter.shared.shortcutSuggestions + [shortcut]
    )

    call.resolve()
  }

  // Called from JS after a successful login to persist the JWT in Keychain.
  // The Siri shortcut handler (FocusIntentHandler) reads this token when
  // invoked outside the app — Keychain is the only secure cross-context store.
  @objc func storeJWT(_ call: CAPPluginCall) {
    guard let token = call.getString("token"), !token.isEmpty else {
      call.reject("Missing token")
      return
    }
    KeychainHelper.shared.writeJWT(token)
    call.resolve()
  }

  // Called from JS on logout to clear the stored JWT.
  @objc func clearJWT(_ call: CAPPluginCall) {
    KeychainHelper.shared.deleteJWT()
    call.resolve()
  }
}
