// KeychainHelper.swift
// Owns: reading and writing the FocusLedger JWT from/to the iOS Keychain.
// Does NOT own: token generation (web layer), token refresh, or auth flow.
//
// WHY Keychain: The JWT must survive app restarts and be accessible to Siri
// shortcut handlers. NSUserDefaults is not secure and not accessible to
// NSUserActivity handlers invoked without the app open. Keychain is the only
// correct storage for this credential.
//
// Drop this file into App/App/ in your Xcode project.
// In your web layer (after login), call the Capacitor bridge to store the token:
//
//   // In your JS auth success handler:
//   import { Capacitor } from '@capacitor/core';
//   if (Capacitor.isNativePlatform()) {
//     Capacitor.Plugins.FocusLedgerSiri?.storeJWT({ token: yourJWT });
//   }

import Foundation
import Security

class KeychainHelper {
  static let shared = KeychainHelper()
  private init() {}

  private let service = "net.focusledger.app"
  private let account = "fl_jwt"

  // Read the stored JWT. Returns nil if not found or on any Keychain error.
  func readJWT() -> String? {
    let query: [CFString: Any] = [
      kSecClass: kSecClassGenericPassword,
      kSecAttrService: service,
      kSecAttrAccount: account,
      kSecReturnData: true,
      kSecMatchLimit: kSecMatchLimitOne,
    ]

    var result: AnyObject?
    let status = SecItemCopyMatching(query as CFDictionary, &result)

    guard status == errSecSuccess,
          let data = result as? Data,
          let token = String(data: data, encoding: .utf8)
    else {
      return nil
    }

    return token
  }

  // Write (or overwrite) the JWT in the Keychain.
  // Called by FocusLedgerSiriPlugin when JS triggers storeJWT().
  func writeJWT(_ token: String) {
    let data = Data(token.utf8)

    // Try update first; if not found, add.
    let query: [CFString: Any] = [
      kSecClass: kSecClassGenericPassword,
      kSecAttrService: service,
      kSecAttrAccount: account,
    ]

    let attributes: [CFString: Any] = [kSecValueData: data]
    var status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)

    if status == errSecItemNotFound {
      var addQuery = query
      addQuery[kSecValueData] = data
      // kSecAttrAccessible: after first unlock — accessible to background fetch from shortcut handlers.
      addQuery[kSecAttrAccessible] = kSecAttrAccessibleAfterFirstUnlock
      status = SecItemAdd(addQuery as CFDictionary, nil)
    }

    if status != errSecSuccess {
      print("[KeychainHelper] writeJWT failed: \(status)")
    }
  }

  // Delete the JWT — call on logout.
  func deleteJWT() {
    let query: [CFString: Any] = [
      kSecClass: kSecClassGenericPassword,
      kSecAttrService: service,
      kSecAttrAccount: account,
    ]
    SecItemDelete(query as CFDictionary)
  }
}
