// AppGroupBridge.swift
// This file belongs in the MAIN APP target (App/App/), NOT the widget extension.
//
// It writes the auth token to the shared App Group UserDefaults container so the
// widget extension can authenticate its API calls without a separate login flow.
//
// WHY App Group UserDefaults (not Keychain group):
// The widget extension process cannot access the main app Keychain items without
// configuring Keychain Access Groups — an extra entitlement that complicates the
// setup. App Group UserDefaults is simpler and sufficient: the JWT is already
// validated server-side, and the shared container is protected by iOS sandbox at
// the same level as other app data. If security requirements escalate, the token
// can be migrated to a shared Keychain group later.
//
// Usage: call AppGroupBridge.saveToken(token) after login; AppGroupBridge.clearToken()
// on logout. Then call WidgetCenter.shared.reloadAllTimelines() to force a widget refresh.

import Foundation
import WidgetKit

enum AppGroupBridge {
    static let appGroupID = "group.net.focusledger.app"
    static let tokenKey   = "widget_auth_token"

    /// Call immediately after the user logs in or the JWT is refreshed.
    static func saveToken(_ token: String) {
        guard let defaults = UserDefaults(suiteName: appGroupID) else { return }
        defaults.set(token, forKey: tokenKey)
        WidgetCenter.shared.reloadAllTimelines()
    }

    /// Call on logout or account switch.
    static func clearToken() {
        guard let defaults = UserDefaults(suiteName: appGroupID) else { return }
        defaults.removeObject(forKey: tokenKey)
        WidgetCenter.shared.reloadAllTimelines()
    }
}

// MARK: - Capacitor Plugin integration
//
// FocusLedger uses Capacitor — the web app doesn't natively call Swift code.
// The bridge is triggered from a Capacitor custom plugin (see AppDelegate note below).
//
// In AppDelegate.swift (or your Capacitor CAPBridgeViewController subclass), intercept
// the JavaScript event "fl_token_updated" and call AppGroupBridge.saveToken(token):
//
//   // In application(_:didFinishLaunchingWithOptions:):
//   NotificationCenter.default.addObserver(
//       forName: NSNotification.Name("fl_token_updated"),
//       object: nil, queue: .main
//   ) { notification in
//       if let token = notification.userInfo?["token"] as? String {
//           AppGroupBridge.saveToken(token)
//       }
//   }
//
// Then in the web app (public/js/app-bridge.js), after login:
//   if (window.Capacitor) {
//     window.Capacitor.nativeCallback({
//       pluginName: 'FLBridge',
//       methodName: 'tokenUpdated',
//       options: { token: localStorage.getItem('fl_token') }
//     });
//   }
//
// See ios-widget/README-widget.md for the complete integration checklist.
