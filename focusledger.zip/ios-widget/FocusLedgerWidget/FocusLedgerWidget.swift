// FocusLedgerWidget.swift
// Main entry point for the FocusLedger Today's Focus home screen widget.
//
// This is the widget extension target — separate from the main app target.
// It uses WidgetKit + SwiftUI, requires iOS 16+.
//
// Architecture:
//   Provider → generates a Timeline of WidgetEntry values
//   WidgetEntry → the snapshot of data at a point in time
//   FocusLedgerWidgetView → the SwiftUI rendering of an entry
//   FocusLedgerWidget → the widget configuration (small + medium)

import WidgetKit
import SwiftUI

// MARK: - Data Model

struct WidgetTask: Codable, Identifiable {
    let id: Int
    let title: String
    let isCompleted: Bool
    let dueDate: String?

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case isCompleted = "is_completed"
        case dueDate = "due_date"
    }
}

struct WidgetTaskResponse: Codable {
    let success: Bool
    let tasks: [WidgetTask]
    let today: String
    let refreshAfter: String?
}

// MARK: - Timeline Entry

struct FocusEntry: TimelineEntry {
    let date: Date
    let tasks: [WidgetTask]
    let isPlaceholder: Bool
    let fetchFailed: Bool

    // Convenience empty state
    static var placeholder: FocusEntry {
        FocusEntry(
            date: Date(),
            tasks: [
                WidgetTask(id: 1, title: "Review budget spreadsheet", isCompleted: false, dueDate: nil),
                WidgetTask(id: 2, title: "Call insurance provider", isCompleted: false, dueDate: nil),
                WidgetTask(id: 3, title: "Pay quarterly taxes", isCompleted: false, dueDate: nil),
            ],
            isPlaceholder: true,
            fetchFailed: false
        )
    }
}

// MARK: - Network

struct WidgetNetwork {
    // WHY stored in UserDefaults (App Group): the widget extension runs in a
    // separate process from the main app and cannot access the app's Keychain
    // group without additional entitlements. The App Group UserDefaults container
    // is shared between app + extension and is the simplest reliable bridge.
    // The token is a JWT already validated server-side — it is not a secret that
    // needs hardware-backed storage. If the user logs out, the main app clears
    // this value and the widget shows the empty state.
    static let appGroupID = "group.net.focusledger.app"
    static let tokenKey = "widget_auth_token"
    static let baseURL = "https://focusledger.polsia.app"

    static func loadToken() -> String? {
        UserDefaults(suiteName: appGroupID)?.string(forKey: tokenKey)
    }

    static func fetchTasks() async -> Result<[WidgetTask], Error> {
        guard let token = loadToken() else {
            return .failure(WidgetError.notLoggedIn)
        }

        guard let url = URL(string: "\(baseURL)/api/widget/tasks") else {
            return .failure(WidgetError.badURL)
        }

        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 10

        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
                return .failure(WidgetError.serverError)
            }
            let decoded = try JSONDecoder().decode(WidgetTaskResponse.self, from: data)
            return .success(decoded.tasks)
        } catch {
            return .failure(error)
        }
    }
}

enum WidgetError: LocalizedError {
    case notLoggedIn
    case badURL
    case serverError

    var errorDescription: String? {
        switch self {
        case .notLoggedIn: return "Not logged in"
        case .badURL: return "Bad URL"
        case .serverError: return "Server error"
        }
    }
}

// MARK: - Timeline Provider

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> FocusEntry {
        .placeholder
    }

    func getSnapshot(in context: Context, completion: @escaping (FocusEntry) -> Void) {
        // Snapshots show in the widget gallery — use placeholder data for speed
        completion(.placeholder)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<FocusEntry>) -> Void) {
        Task {
            let result = await WidgetNetwork.fetchTasks()

            let entry: FocusEntry
            switch result {
            case .success(let tasks):
                entry = FocusEntry(date: Date(), tasks: tasks, isPlaceholder: false, fetchFailed: false)
            case .failure:
                entry = FocusEntry(date: Date(), tasks: [], isPlaceholder: false, fetchFailed: true)
            }

            // Refresh every 30 minutes. WidgetKit throttles refreshes to preserve battery —
            // 30 min is a good balance between freshness and system resource use.
            // After midnight, WidgetKit will also naturally refresh on the next scheduled slot.
            let nextRefresh = Calendar.current.date(byAdding: .minute, value: 30, to: Date()) ?? Date()

            let timeline = Timeline(entries: [entry], policy: .after(nextRefresh))
            completion(timeline)
        }
    }
}

// MARK: - Widget Entry View (Small + Medium)

struct FocusLedgerWidgetView: View {
    @Environment(\.widgetFamily) var family
    var entry: FocusEntry

    var body: some View {
        switch family {
        case .systemSmall:
            SmallWidgetView(entry: entry)
        case .systemMedium:
            MediumWidgetView(entry: entry)
        default:
            SmallWidgetView(entry: entry)
        }
    }
}

// MARK: - Small Widget (shows header + top 1 task)

struct SmallWidgetView: View {
    var entry: FocusEntry

    var body: some View {
        ZStack {
            Color("WidgetBackground")

            VStack(alignment: .leading, spacing: 6) {
                // Header
                HStack(spacing: 4) {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(Color("AccentGreen"))
                    Text("Today's Focus")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(Color("TextSecondary"))
                }

                Spacer()

                // Content
                if entry.fetchFailed {
                    Text("Tap to open FocusLedger")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(Color("TextSecondary"))
                        .multilineTextAlignment(.leading)
                } else if entry.tasks.isEmpty {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("🎉")
                            .font(.system(size: 20))
                        Text("No tasks\ntoday!")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(Color("TextPrimary"))
                    }
                } else {
                    Text(entry.tasks[0].title)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Color("TextPrimary"))
                        .lineLimit(3)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
    }
}

// MARK: - Medium Widget (shows header + top 3 tasks)

struct MediumWidgetView: View {
    var entry: FocusEntry

    var body: some View {
        ZStack {
            Color("WidgetBackground")

            VStack(alignment: .leading, spacing: 0) {
                // Header row
                HStack {
                    HStack(spacing: 4) {
                        Image(systemName: "brain.head.profile")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(Color("AccentGreen"))
                        Text("Today's Focus")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(Color("TextSecondary"))
                    }
                    Spacer()
                    if !entry.isPlaceholder {
                        Text("\(entry.tasks.count) task\(entry.tasks.count == 1 ? "" : "s")")
                            .font(.system(size: 11))
                            .foregroundColor(Color("TextSecondary"))
                    }
                }
                .padding(.bottom, 10)

                // Task list or empty state
                if entry.fetchFailed {
                    Spacer()
                    Text("Unable to load — tap to open FocusLedger")
                        .font(.system(size: 13))
                        .foregroundColor(Color("TextSecondary"))
                    Spacer()
                } else if entry.tasks.isEmpty {
                    Spacer()
                    HStack(spacing: 8) {
                        Text("🎉")
                            .font(.system(size: 22))
                        Text("No tasks today!")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(Color("TextPrimary"))
                    }
                    Spacer()
                } else {
                    ForEach(entry.tasks) { task in
                        TaskRow(task: task)
                        if task.id != entry.tasks.last?.id {
                            Divider()
                                .background(Color("Divider"))
                                .padding(.vertical, 4)
                        }
                    }
                }

                Spacer(minLength: 0)
            }
            .padding(14)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
    }
}

// MARK: - Task Row (used in medium widget)

struct TaskRow: View {
    var task: WidgetTask

    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            // Checkbox (visual only — interactive widgets require iOS 17)
            Image(systemName: "circle")
                .font(.system(size: 16, weight: .light))
                .foregroundColor(Color("AccentGreen"))
                .frame(width: 20)

            Text(task.title)
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(Color("TextPrimary"))
                .lineLimit(2)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

// MARK: - Widget Configuration

@main
struct FocusLedgerWidget: Widget {
    let kind: String = "FocusLedgerWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            // Tapping any part of the widget opens the main app's task view.
            // The widgetURL links to focusledger:// deep link which Capacitor handles.
            FocusLedgerWidgetView(entry: entry)
                .widgetURL(URL(string: "focusledger://tasks"))
                .containerBackground(Color("WidgetBackground"), for: .widget)
        }
        .configurationDisplayName("Today's Focus")
        .description("See your top tasks for today at a glance.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

// MARK: - Previews

struct FocusLedgerWidget_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            FocusLedgerWidgetView(entry: .placeholder)
                .previewContext(WidgetPreviewContext(family: .systemSmall))
                .previewDisplayName("Small – Tasks")

            FocusLedgerWidgetView(entry: .placeholder)
                .previewContext(WidgetPreviewContext(family: .systemMedium))
                .previewDisplayName("Medium – Tasks")

            FocusLedgerWidgetView(entry: FocusEntry(date: Date(), tasks: [], isPlaceholder: false, fetchFailed: false))
                .previewContext(WidgetPreviewContext(family: .systemMedium))
                .previewDisplayName("Medium – Empty")
        }
    }
}
