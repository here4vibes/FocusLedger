# FocusLedger Widget — Integration Guide

Home screen widget showing today's top 3 tasks. Built with WidgetKit + SwiftUI.
Requires iOS 16+. Works for both small (2×2) and medium (4×2) widget sizes.

## Architecture at a Glance

```
Web app (JS) → localStorage token → FLBridge.notifyTokenUpdated()
                                         ↓ Capacitor native bridge
                               AppGroupBridge.saveToken(token)
                                         ↓ App Group UserDefaults
                               FocusLedgerWidget / Provider.getTimeline()
                                         ↓ HTTPS to focusledger.polsia.app
                               GET /api/widget/tasks (Bearer token)
                                         ↓ JSON
                               WidgetKit renders task list
```

## Files in This Directory

| File | Where it goes | Purpose |
|------|--------------|---------|
| `FocusLedgerWidget/FocusLedgerWidget.swift` | Widget extension target | All SwiftUI + WidgetKit code |
| `FocusLedgerWidget/Assets.xcassets/` | Widget extension target | Color assets (light + dark) |
| `AppGroupBridge.swift` | Main app target (App/App/) | Writes token to shared container |
| `app-bridge.js` | `public/js/app-bridge.js` | Web JS that notifies Swift of token |

## Step-by-Step Integration (macOS + Xcode required)

### 1. Add App Group Entitlement

The widget and main app share data via an App Group container. Configure it in **both** targets.

**Main app target (App):**
1. Xcode → select `App` target → `Signing & Capabilities`
2. Click `+ Capability` → add **App Groups**
3. Click `+` → enter `group.net.focusledger.app`

**Widget extension target (FocusLedgerWidget) — same steps.**

> **Why this ID?** It matches the `appGroupID` constant in both `FocusLedgerWidget.swift` and `AppGroupBridge.swift`. If you use a different ID, update both files.

### 2. Add the Widget Extension Target

1. Xcode → **File → New → Target**
2. Select **Widget Extension** → Next
3. Product Name: `FocusLedgerWidget`
4. Bundle Identifier: `net.focusledger.app.widget`
5. **Uncheck** "Include Configuration Intent" (no user config in v1)
6. Finish — Xcode creates the extension target

### 3. Replace Generated Files with This Repo's Files

Xcode generates boilerplate. Replace it:

```bash
# From repo root — copy widget source files into the generated extension
cp ios-widget/FocusLedgerWidget/FocusLedgerWidget.swift ios/App/FocusLedgerWidget/FocusLedgerWidget.swift

# Copy color assets (replace the generated Assets.xcassets in the widget target)
cp -r ios-widget/FocusLedgerWidget/Assets.xcassets/ ios/App/FocusLedgerWidget/Assets.xcassets/
```

Then in Xcode, confirm the extension's file list shows `FocusLedgerWidget.swift` (not the boilerplate `FocusLedgerWidgetBundle.swift` etc — delete those if they were generated).

### 4. Add AppGroupBridge to Main App Target

1. Drag `ios-widget/AppGroupBridge.swift` into Xcode → `App/App/` group
2. In the file addition dialog, check **only** the `App` target (not the widget)
3. This file adds `AppGroupBridge.saveToken()` / `AppGroupBridge.clearToken()` to the main app

### 5. Wire the Native Notification in AppDelegate

Open `ios/App/App/AppDelegate.swift`. In `application(_:didFinishLaunchingWithOptions:)`, add:

```swift
// Listen for token updates from the web layer via Capacitor bridge
NotificationCenter.default.addObserver(
    forName: NSNotification.Name("fl_token_updated"),
    object: nil,
    queue: .main
) { notification in
    if let token = notification.userInfo?["token"] as? String {
        AppGroupBridge.saveToken(token)
    }
}

// Listen for logout — clear the widget token
NotificationCenter.default.addObserver(
    forName: NSNotification.Name("fl_token_cleared"),
    object: nil,
    queue: .main
) { _ in
    AppGroupBridge.clearToken()
}
```

### 6. Add the JS Bridge to the Web Layer

1. Copy `ios-widget/app-bridge.js` → `public/js/app-bridge.js`
2. Include it in `public/app.html` (or wherever your main authenticated JS loads):

```html
<script src="/js/app-bridge.js"></script>
```

3. After login succeeds (where you currently call `localStorage.setItem('token', ...)`), add:

```javascript
// Notify native widget of updated token
if (window.FLBridge) FLBridge.notifyTokenUpdated();
```

4. After logout, add:

```javascript
if (window.FLBridge) FLBridge.notifyLogout();
```

### 7. Configure Minimum Deployment Target

In Xcode → Widget extension target → **General → Minimum Deployments**:
- Set to **iOS 16.0** (WidgetKit minimum)

### 8. Build and Test on Simulator

```bash
npx cap sync ios
npx cap open ios
```

In Xcode:
1. Select an iPhone 16 simulator
2. Build and run the **App** scheme (not the widget scheme directly)
3. Long-press the simulator home screen → add widget → search "FocusLedger"
4. Add the medium widget — you should see tasks after logging in

**If widget shows empty state:** Check that:
- App Group is configured on both targets
- The JS `FLBridge.notifyTokenUpdated()` call fires after login
- `UserDefaults(suiteName: "group.net.focusledger.app")?.string(forKey: "widget_auth_token")` returns a non-nil value in the widget (add a debug print to `Provider.getTimeline` to verify)

## API Endpoint

The widget fetches from `GET /api/widget/tasks`.

**Request:**
```
GET https://focusledger.polsia.app/api/widget/tasks
Authorization: Bearer <jwt>
```

**Response:**
```json
{
  "success": true,
  "tasks": [
    { "id": 42, "title": "File Q1 taxes", "is_completed": false, "due_date": "2026-05-18" },
    { "id": 43, "title": "Call insurance", "is_completed": false, "due_date": null }
  ],
  "today": "2026-05-18",
  "refreshAfter": "2026-05-18T23:59:59"
}
```

Returns at most 3 tasks. Priority: overdue incomplete → due today → created today, no due date.

## Dark Mode

All colors are defined in `Assets.xcassets` as adaptive color sets with light + dark variants. WidgetKit uses the system appearance automatically — no code changes needed.

Color palette:
- `AccentGreen` — #42D160 (light) / #57DB78 (dark) — matches FocusLedger's brand green
- `TextPrimary` — #222222 (light) / #F4F5F8 (dark)
- `TextSecondary` — #747474 (light) / #9E9E9E (dark)
- `WidgetBackground` — #FFFFFF (light) / #1E1E1E (dark)
- `Divider` — black 12% opacity (light) / white 15% opacity (dark)

## v2 Ideas (not in scope)

- **Interactive checkboxes** — iOS 17 AppIntents. When checked, fires `POST /api/tasks/:id/complete` and calls `WidgetCenter.shared.reloadAllTimelines()`.
- **Configurable focus area** — WidgetKit IntentConfiguration lets users pick which task category to show.
- **Lock screen widget** — `.accessoryRectangular` / `.accessoryCircular` families.
