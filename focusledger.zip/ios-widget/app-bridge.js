/**
 * app-bridge.js — FocusLedger widget token bridge
 *
 * Add this file to the main app bundle (public/js/) and include it in your
 * authenticated pages. It detects the Capacitor native context and notifies
 * Swift to update the widget's auth token after login.
 *
 * USAGE: Include after the auth token is stored in localStorage:
 *   <script src="/js/app-bridge.js"></script>
 *   // Then call:
 *   FLBridge.notifyTokenUpdated();
 *
 * The Swift side (AppGroupBridge.swift) receives the notification and writes
 * the token to the shared App Group container. WidgetKit refreshes automatically.
 */

(function () {
  'use strict';

  // Only meaningful in the Capacitor native shell — no-ops in the browser.
  const isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

  const FLBridge = {
    /**
     * Call after login or token refresh. Reads the JWT from localStorage
     * (key: 'token' — matches what FocusLedger stores on login) and sends it
     * to Swift via a Capacitor notification so the widget can authenticate.
     */
    notifyTokenUpdated: function () {
      if (!isNative) return;

      const token = localStorage.getItem('token');
      if (!token) return;

      try {
        // WHY window.Capacitor.nativeCallback: This is the simplest Capacitor
        // mechanism to pass data from JS to Swift without a full custom plugin.
        // The Swift side listens on NotificationCenter for 'fl_token_updated'.
        window.Capacitor.nativeCallback({
          pluginName: 'FLBridge',
          methodName: 'tokenUpdated',
          options: { token: token }
        });
      } catch (e) {
        // Fail silently — widget feature is progressive enhancement only.
        // If the bridge doesn't work, the widget just shows "tap to open app."
      }
    },

    /**
     * Call on logout. Clears the widget token via native bridge so the widget
     * shows the logged-out empty state rather than stale tasks.
     */
    notifyLogout: function () {
      if (!isNative) return;

      try {
        window.Capacitor.nativeCallback({
          pluginName: 'FLBridge',
          methodName: 'tokenCleared',
          options: {}
        });
      } catch (e) {
        // Fail silently.
      }
    }
  };

  window.FLBridge = FLBridge;
})();
