# FocusLedger E2E Tests

Playwright-based end-to-end test suite. Runs on mobile viewport (iPhone 13) against the deployed app.

## Quickstart

```bash
# Install playwright browsers once
npx playwright install chromium --with-deps

# Run the full suite
npm run test:e2e

# Open interactive UI mode (watch + visual trace)
npm run test:e2e:ui

# Debug a specific test
npm run test:e2e:debug tests/e2e/tests/04-add-value-preset.spec.js
```

## Configuration

Tests target `https://focusledger.polsia.app` by default. Override with:

```bash
BASE_URL=http://localhost:3000 npm run test:e2e
```

### Required secrets (for CI):

| Secret | Description |
|--------|-------------|
| `E2E_USER_EMAIL` | Test user email (default: `e2e.bot@focusledger-e2e.test`) |
| `E2E_USER_PASSWORD` | Test user password |

Set these in GitHub → Settings → Secrets → Actions.

## Test Coverage (10 critical flows)

| File | What it tests |
|------|--------------|
| `01-signup-login.spec.js` | Signup, login, invalid credentials |
| `02-task-complete-celebration.spec.js` | Create task → mark complete → confetti fires |
| `03-free-tier-limit.spec.js` | Free tier: hit 10-task cap → upgrade modal appears |
| `04-add-value-preset.spec.js` | **Regression:** `value_name is required` bug; add value via API and UI |
| `05-nudges-toggle.spec.js` | **Regression:** Notification toggle in Settings responds to click |
| `06-ai-suggestions.spec.js` | "Suggested for You" renders; accepting creates a task |
| `07-expense-tracker.spec.js` | Add manual expense → appears in list, budget updates |
| `08-pricing-stripe.spec.js` | Pricing page loads; Pro button links to Stripe |
| `09-subscription-management.spec.js` | Settings subscription section loads correctly |
| `10-dashboard-no-errors.spec.js` | Dashboard full-load, zero console errors, auth redirect |

## How to add a test for a new feature

**Rule: every new feature task ships with a corresponding e2e test.**

1. Create a new file in `tests/e2e/tests/` — number it sequentially or use a descriptive name.
2. Import from `@playwright/test`:
   ```js
   const { test, expect } = require('@playwright/test');
   ```
3. Tests get the authenticated test user by default (via `storageState` in `playwright.config.js`).
4. If your test needs a **fresh unauthenticated context**, override at the top:
   ```js
   test.use({ storageState: { cookies: [], origins: [] } });
   ```
5. For tests that call the API directly, grab the token from localStorage:
   ```js
   const token = await page.evaluate(() => localStorage.getItem('fl_token'));
   const res = await page.request.get('/api/tasks', {
     headers: { 'Authorization': `Bearer ${token}` },
   });
   ```
6. **Always clean up** created data at the end of your test. Tests run against the real production database.
7. Run locally before pushing:
   ```bash
   npm run test:e2e
   ```

## CI integration

The GitHub Actions workflow (`.github/workflows/e2e.yml`) runs the suite:
- On every push to `main` (post-deploy regression check)
- On every pull request (health check against current prod)

PRs are blocked from merging if any test fails. Artifacts (HTML report + traces) are uploaded on failure.

## Architecture notes

- **Viewport**: iPhone 13 (390×844) — matches primary user surface
- **Auth**: `tests/e2e/auth.setup.js` logs in as the test user and saves `storageState` (includes `localStorage`). This runs once per suite, not per test.
- **Global setup**: `tests/e2e/global-setup.js` creates the test user via API before any browser opens.
- **Parallel execution**: 4 workers in CI. Tests are independent and run concurrently.
- **Target**: Tests always run against the deployed URL, not a local server. This catches deploy-time issues.

## Debugging failures

1. Check the GitHub Actions run — "Upload test results" artifact contains the HTML report.
2. Traces are uploaded on failure — open with `npx playwright show-trace trace.zip`.
3. Locally: `npm run test:e2e:debug` opens Playwright Inspector for step-by-step debugging.
