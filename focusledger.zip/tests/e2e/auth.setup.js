/**
 * Auth setup — runs once per suite execution.
 * Logs in as the E2E test user and saves storage state (including localStorage fl_token).
 */

const { test: setup, expect } = require('@playwright/test');
const path = require('path');

const authFile = path.join(__dirname, '.auth/user.json');

setup('authenticate as e2e test user', async ({ page }) => {
  const email = process.env.E2E_USER_EMAIL || 'e2e.bot@focusledger-e2e.test';
  const password = process.env.E2E_USER_PASSWORD || 'E2eBot_Pass_2026!';

  await page.goto('/login');

  await expect(page.locator('#email')).toBeVisible({ timeout: 10000 });
  await page.fill('#email', email);
  await page.fill('#password', password);
  await page.click('#submitBtn');

  // Wait for redirect to /app — confirms login succeeded
  await page.waitForURL('**/app', { timeout: 15000 });
  await expect(page.locator('#taskInput')).toBeVisible({ timeout: 10000 });

  // Save storage state — includes localStorage with fl_token
  await page.context().storageState({ path: authFile });
  console.log('[E2E] Auth state saved to', authFile);
});
