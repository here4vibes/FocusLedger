/**
 * Global setup — runs once before all Playwright e2e tests.
 * Creates (or confirms) the canonical QA user via API signup.
 *
 * Credentials sourced from config/test-users.js.
 * Env vars E2E_USER_EMAIL / E2E_USER_PASSWORD override the config defaults
 * for CI environments that inject credentials at runtime.
 */

const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { QA_USER } = require('../../config/test-users');

const BASE_URL = process.env.BASE_URL || 'https://focusledger.polsia.app';
const EMAIL = process.env.E2E_USER_EMAIL || QA_USER.email;
const PASSWORD = process.env.E2E_USER_PASSWORD || QA_USER.password;

function post(url, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const isHttps = url.startsWith('https');
    const lib = isHttps ? https : http;
    const urlObj = new URL(url);

    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: urlObj.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
      },
    };

    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });

    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

module.exports = async function globalSetup() {
  console.log('[E2E] Creating test user:', EMAIL);

  // Ensure .auth dir exists
  const authDir = path.join(__dirname, '.auth');
  if (!fs.existsSync(authDir)) {
    fs.mkdirSync(authDir, { recursive: true });
  }

  const res = await post(`${BASE_URL}/api/auth/signup`, {
    email: EMAIL,
    password: PASSWORD,
    name: QA_USER.displayName,
  });

  if (res.status === 201) {
    console.log('[E2E] Test user created successfully.');
  } else if (res.status === 409) {
    console.log('[E2E] Test user already exists — continuing.');
  } else {
    console.error('[E2E] Unexpected response:', res.status, res.body);
    throw new Error(`[E2E] Failed to create test user: ${res.status} ${JSON.stringify(res.body)}`);
  }
};
