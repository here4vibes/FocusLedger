/**
 * Test 01: Signup + Login
 *
 * Covers:
 *  - New user signup via email/password → redirect to /app
 *  - Existing user login → redirect to /app
 *  - Invalid credentials → error message shown
 *
 * Credentials for the existing-user login test are sourced from
 * config/test-users.js (canonical QA user). Signup test uses a
 * unique email each run to avoid 409 conflicts.
 */

const { test, expect } = require('@playwright/test');
const { QA_USER } = require('../../../config/test-users');

// These tests exercise authentication, so they use a fresh (no pre-seeded) state.
test.use({ storageState: { cookies: [], origins: [] } });

test.describe('Signup + Login', () => {
  test('signup: new user creates account and lands on /app', async ({ page }) => {
    // Use a unique email each run to avoid 409 conflicts
    const uniqueId = Date.now().toString(36);
    const email = `e2e.signup.${uniqueId}@focusledger-e2e.test`;
    const password = 'TestPass123!';

    await page.goto('/signup');
    await expect(page.locator('#submitBtn')).toBeVisible({ timeout: 10000 });

    await page.fill('#name', 'E2E Signup User');
    await page.fill('#email', email);
    await page.fill('#password', password);
    await page.click('#submitBtn');

    // After signup → redirect to /app
    await page.waitForURL('**/app', { timeout: 15000 });
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 10000 });
  });

  test('login: existing user authenticates and lands on /app', async ({ page }) => {
    const email = process.env.E2E_USER_EMAIL || QA_USER.email;
    const password = process.env.E2E_USER_PASSWORD || QA_USER.password;

    await page.goto('/login');
    await expect(page.locator('#submitBtn')).toBeVisible({ timeout: 10000 });

    await page.fill('#email', email);
    await page.fill('#password', password);
    await page.click('#submitBtn');

    await page.waitForURL('**/app', { timeout: 15000 });
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 10000 });
  });

  test('login: wrong credentials shows error message', async ({ page }) => {
    await page.goto('/login');
    await expect(page.locator('#submitBtn')).toBeVisible({ timeout: 10000 });

    await page.fill('#email', 'nobody@focusledger-e2e.test');
    await page.fill('#password', 'wrongpassword');
    await page.click('#submitBtn');

    await expect(page.locator('#errorMsg')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('#errorMsg')).not.toBeEmpty();
  });
});
