/**
 * Test 02: Create task → Mark complete → Celebration shows
 *
 * Covers:
 *  - Typing in task input and submitting
 *  - Task appears in task list
 *  - Clicking the task checkbox marks it complete
 *  - Confetti/celebration fires on completion
 */

const { test, expect } = require('@playwright/test');

test.describe('Create task → Complete → Celebrate', () => {
  test('task can be created and marked complete', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    const taskTitle = `E2E task ${Date.now()}`;

    // Add task
    await page.fill('#taskInput', taskTitle);
    await page.click('#addTaskBtn');

    // Task appears in list
    await expect(page.locator('#taskList')).toContainText(taskTitle, { timeout: 8000 });

    // Find the new task's checkbox and click it
    const taskCard = page.locator('.task-card').filter({ hasText: taskTitle });
    await expect(taskCard).toBeVisible({ timeout: 5000 });
    const checkbox = taskCard.locator('.task-checkbox[data-action="toggle-task"]');
    await expect(checkbox).toBeVisible();
    await checkbox.click();

    // Task should show as completed (has "done" class or struck title)
    await expect(taskCard.locator('.task-title.struck, .task-checkbox.done')).toBeVisible({ timeout: 5000 });

    // Confetti container should have pieces (fires on completion)
    // Confetti pieces are added dynamically and removed after ~1.8s
    // We just verify the container exists and there's no JS error
    await expect(page.locator('#confettiContainer')).toBeAttached();
  });

  test('task input clears after submission', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    await page.fill('#taskInput', `E2E clear test ${Date.now()}`);
    await page.click('#addTaskBtn');

    // Input should be cleared
    await expect(page.locator('#taskInput')).toHaveValue('', { timeout: 5000 });
  });
});
