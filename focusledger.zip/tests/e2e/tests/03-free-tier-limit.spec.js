/**
 * Test 03: Free tier — hit 10-task limit → upgrade prompt appears
 *
 * Strategy: Use the API to create enough tasks to hit the free limit,
 * then try to add one more via the UI and verify the upgrade modal appears.
 *
 * This test always cleans up the tasks it creates.
 */

const { test, expect } = require('@playwright/test');

test.describe('Free tier task limit', () => {
  test('upgrade modal appears when task limit is reached', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    // Get current token from localStorage
    const token = await page.evaluate(() => localStorage.getItem('fl_token'));
    expect(token).toBeTruthy();

    const baseURL = process.env.BASE_URL || 'https://focusledger.polsia.app';
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    };

    // Fetch current active tasks
    const listRes = await page.request.get(`${baseURL}/api/tasks`, { headers });
    const listData = await listRes.json();
    const activeTasks = (listData.tasks || []).filter(t => !t.is_completed);
    const taskIdsToCleanup = [];

    // Create enough tasks to reach limit of 10
    const needed = Math.max(0, 10 - activeTasks.length);
    for (let i = 0; i < needed; i++) {
      const res = await page.request.post(`${baseURL}/api/tasks`, {
        headers,
        data: { title: `E2E limit test task ${i + 1}` },
      });
      const data = await res.json();
      if (data.task) taskIdsToCleanup.push(data.task.id);
    }

    // Refresh page to pick up task count
    await page.reload();
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    // Try to add one more task — should trigger upgrade modal
    await page.fill('#taskInput', `E2E over-limit task ${Date.now()}`);
    await page.click('#addTaskBtn');

    // Upgrade modal should appear
    await expect(page.locator('#upgradeModal')).toBeVisible({ timeout: 8000 });
    await expect(page.locator('#upgradeModal')).toContainText(/pro|upgrade|limit/i);

    // Cleanup: delete tasks we created
    for (const id of taskIdsToCleanup) {
      await page.request.delete(`${baseURL}/api/tasks/${id}`, { headers }).catch(() => {});
    }
  });

  test('task limit banner shows active task count for free users', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    // Check if limit banner exists (it shows when free user is near/at limit)
    // This just validates the element renders without error
    const banner = page.locator('#taskLimitBanner');
    // Banner may or may not be visible depending on task count — just check it exists in DOM
    await expect(banner).toBeAttached();
  });
});
