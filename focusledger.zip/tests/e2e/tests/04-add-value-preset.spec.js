/**
 * Test 04: Add a value from the values setup flow
 *
 * REGRESSION: "value_name is required" bug
 * The quick-pick sheet POSTs to /api/values/bulk. This test verifies that
 * preset value submission succeeds and does NOT throw "value_name is required".
 *
 * Also tests the /values page flow directly.
 */

const { test, expect } = require('@playwright/test');

test.describe('Add value — setup flow (regression: value_name is required)', () => {
  /**
   * Direct API regression test: POST /api/values/bulk with auth header must succeed.
   * This catches the exact bug where auth header was missing and the request failed.
   */
  test('API: POST /api/values/bulk with auth succeeds', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    const token = await page.evaluate(() => localStorage.getItem('fl_token'));
    expect(token).toBeTruthy();

    const baseURL = process.env.BASE_URL || 'https://focusledger.polsia.app';

    // Call the bulk endpoint with proper auth — same payload the quick-pick sheet sends
    const res = await page.request.post(`${baseURL}/api/values/bulk`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      data: {
        values: [{ value_name: 'E2E Health', icon: '💪', color: '#F26B3A' }],
      },
    });

    const body = await res.json();

    // Must NOT return "value_name is required" — that's the bug
    expect(body.message).not.toBe('value_name is required');
    expect(body.message).not.toMatch(/value_name.*required/i);

    // Should succeed (or fail with "Would exceed 10-value limit" if already full — that's fine)
    const acceptable = body.success === true || (body.message && body.message.includes('exceed'));
    expect(acceptable, `Unexpected response: ${JSON.stringify(body)}`).toBe(true);

    // Cleanup: delete the test value if it was created
    if (body.success && body.values) {
      for (const v of body.values) {
        await page.request.delete(`${baseURL}/api/values/${v.id}`, {
          headers: { 'Authorization': `Bearer ${token}` },
        }).catch(() => {});
      }
    }
  });

  /**
   * UI test: Values page — type a value name and save.
   * This covers the standard "add a value" flow.
   */
  test('UI: add a value from /values page succeeds', async ({ page }) => {
    await page.goto('/values');

    const token = await page.evaluate(() => localStorage.getItem('fl_token'));
    expect(token).toBeTruthy();

    const baseURL = process.env.BASE_URL || 'https://focusledger.polsia.app';

    // Look for add-value button (text varies: "Add my first value" or "Add another value" or a + button)
    const addBtn = page.locator(
      'button:has-text("Add my first value"), button:has-text("Add another value"), button:has-text("+ Add value"), #addValueBtn, .btn-add-value'
    ).first();

    await expect(addBtn).toBeVisible({ timeout: 10000 });
    await addBtn.click();

    // Wait for input to appear
    const nameInput = page.locator('#inputValueName');
    await expect(nameInput).toBeVisible({ timeout: 5000 });

    const valueName = `E2E Value ${Date.now().toString(36)}`;
    await page.fill('#inputValueName', valueName);

    // Click save
    const saveBtn = page.locator('#saveValueBtn');
    await expect(saveBtn).toBeVisible();
    await saveBtn.click();

    // Modal should close — no error shown
    await expect(nameInput).not.toBeVisible({ timeout: 5000 });

    // The new value should appear in the values list
    await expect(page.locator('.value-name, [class*="value-name"]')).toContainText(valueName, { timeout: 5000 });

    // Cleanup: find and delete the value we just created
    const listRes = await page.request.get(`${baseURL}/api/values`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const listData = await listRes.json();
    const testValue = (listData.values || []).find(v => v.value_name === valueName);
    if (testValue) {
      await page.request.delete(`${baseURL}/api/values/${testValue.id}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      }).catch(() => {});
    }
  });
});
