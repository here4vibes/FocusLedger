/**
 * Test 05: Toggle nudges on/off in settings and verify persistence
 *
 * REGRESSION: Nudges toggle not working
 *
 * Tests the notification toggle in /settings.
 * Verifies the toggle responds to user interaction and the UI reflects the state change.
 *
 * Note: In Playwright, push notification permission can be granted via browser context.
 */

const { test, expect } = require('@playwright/test');

test.describe('Settings — nudges/notifications toggle', () => {
  // Grant notification permission so the notification UI shows (not "unsupported")
  test.use({
    permissions: ['notifications'],
  });

  test('notification toggle renders and responds to click', async ({ page }) => {
    await page.goto('/settings');

    // Wait for settings page to load
    await expect(page.locator('h1')).toContainText('Settings', { timeout: 10000 });

    // Wait for notification support check to complete
    await expect(page.locator('#notifLoading')).not.toBeVisible({ timeout: 8000 });

    // If notifications are supported, the toggle should be visible
    const notifContent = page.locator('#notifContent');
    const notifUnsupported = page.locator('#notifUnsupported');

    const isSupported = await notifContent.isVisible({ timeout: 3000 }).catch(() => false);

    if (!isSupported) {
      // Notifications not supported in this browser — this test is informational only
      // The unsupported message should be visible
      const unsupportedVisible = await notifUnsupported.isVisible();
      if (unsupportedVisible) {
        console.log('[E2E] Notifications not supported in this browser context — skipping toggle test');
        test.skip();
        return;
      }
    }

    // Toggle should be visible
    const toggle = page.locator('#notifToggle');
    await expect(toggle).toBeVisible({ timeout: 5000 });

    const label = page.locator('#notifToggleLabel');
    const initialLabel = await label.textContent();

    // Click the toggle
    await toggle.click();

    // Label should change (Off → On or On → Off)
    await expect(label).not.toHaveText(initialLabel || '', { timeout: 5000 });
  });

  test('notification toggle state is reflected in aria-checked attribute', async ({ page }) => {
    await page.goto('/settings');

    await expect(page.locator('h1')).toContainText('Settings', { timeout: 10000 });
    await expect(page.locator('#notifLoading')).not.toBeVisible({ timeout: 8000 });

    const notifContent = page.locator('#notifContent');
    const isVisible = await notifContent.isVisible({ timeout: 3000 }).catch(() => false);

    if (!isVisible) {
      test.skip();
      return;
    }

    const toggle = page.locator('#notifToggle');
    await expect(toggle).toBeVisible();

    // Read initial state
    const initialChecked = await toggle.getAttribute('aria-checked');

    // Click toggle
    await toggle.click();

    // aria-checked should flip
    const expected = initialChecked === 'true' ? 'false' : 'true';
    await expect(toggle).toHaveAttribute('aria-checked', expected, { timeout: 5000 });
  });
});
