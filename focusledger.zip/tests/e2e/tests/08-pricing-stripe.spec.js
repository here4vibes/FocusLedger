/**
 * Test 08: Pricing page → Stripe checkout loads
 *
 * Covers:
 *  - Pricing page renders with Pro plan card
 *  - "Upgrade to Pro" button has correct Stripe URL (buy.stripe.com)
 *  - Clicking the button navigates to a Stripe checkout URL
 *    (we don't go all the way through checkout — just verify the link works)
 */

const { test, expect } = require('@playwright/test');

test.describe('Pricing page — Stripe checkout', () => {
  test('pricing page loads with Pro plan visible', async ({ page }) => {
    await page.goto('/pricing');

    // Page renders
    await expect(page.locator('.pricing-card.featured, .plan-name')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('text=Pro')).toBeVisible();
    await expect(page.locator('text=Upgrade to Pro')).toBeVisible();
  });

  test('Pro upgrade button links to Stripe checkout', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#proBtn')).toBeVisible({ timeout: 10000 });

    const proBtn = page.locator('#proBtn');
    const href = await proBtn.getAttribute('href');

    // Button must link to Stripe — not a dead link (#) or empty
    expect(href).toBeTruthy();
    expect(href).not.toBe('#');
    expect(href).toMatch(/stripe\.com|stripecdn\.com/i);
  });

  test('billing toggle switches between monthly and annual pricing', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#proBtn')).toBeVisible({ timeout: 10000 });

    const priceAmount = page.locator('#proPriceAmount');
    const monthlyAmount = await priceAmount.textContent();

    // Switch to annual
    const annualLabel = page.locator('#annualLabel');
    if (await annualLabel.isVisible()) {
      await annualLabel.click();
      const annualAmount = await priceAmount.textContent();
      // Annual price should be different (lower per-month)
      expect(annualAmount).not.toBe(monthlyAmount);
    }
  });
});
