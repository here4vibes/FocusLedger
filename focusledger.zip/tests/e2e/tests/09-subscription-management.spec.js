/**
 * Test 09: Settings → manage subscription link works
 *
 * Covers:
 *  - Settings page loads subscription info
 *  - Free users see upgrade link pointing to /pricing
 *  - Pro users see subscription details and cancel option
 */

const { test, expect } = require('@playwright/test');

test.describe('Settings — subscription management', () => {
  test('settings page loads without error', async ({ page }) => {
    await page.goto('/settings');

    await expect(page.locator('h1')).toContainText('Settings', { timeout: 10000 });

    // Subscription section should load
    await expect(page.locator('#subLoading')).not.toBeVisible({ timeout: 10000 });
    await expect(page.locator('#subContent')).toBeVisible({ timeout: 10000 });
  });

  test('free user sees upgrade link to /pricing', async ({ page }) => {
    await page.goto('/settings');

    await expect(page.locator('#subContent')).toBeVisible({ timeout: 10000 });

    const content = page.locator('#subContent');
    const text = await content.textContent();

    // Free users see "FREE" badge and upgrade link
    // Pro users see "PRO" badge — we test what we can without knowing which tier the test user is
    if (text && text.includes('FREE')) {
      // Free user — upgrade link should be visible
      const upgradeLink = content.locator('a[href="/pricing"]');
      await expect(upgradeLink).toBeVisible({ timeout: 5000 });
      await expect(upgradeLink).toContainText(/upgrade|pro/i);
    } else if (text && text.includes('PRO')) {
      // Pro user — cancel or reactivate button should be present
      const manageBtn = content.locator('button, a').filter({ hasText: /cancel|manage|reactivate/i }).first();
      await expect(manageBtn).toBeVisible({ timeout: 5000 });
    }
  });

  test('usage section loads with active task count', async ({ page }) => {
    await page.goto('/settings');

    await expect(page.locator('#usageLoading')).not.toBeVisible({ timeout: 10000 });
    await expect(page.locator('#usageContent')).toBeVisible({ timeout: 10000 });

    // Usage section should mention "Active tasks"
    await expect(page.locator('#usageContent')).toContainText(/active tasks/i, { timeout: 5000 });
  });
});
