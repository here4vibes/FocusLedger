/**
 * Test 10: Dashboard loads end-to-end without console errors
 *
 * Covers:
 *  - /app loads within timeout
 *  - All critical sections render (task list, spending, AI suggestions)
 *  - No console errors or uncaught exceptions thrown
 *  - Auth check works (redirect to /login if not authenticated)
 */

const { test, expect } = require('@playwright/test');

test.describe('Dashboard — full load, no console errors', () => {
  test('dashboard loads all sections without console errors', async ({ page }) => {
    const consoleErrors = [];

    // Collect console errors
    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        // Filter out known third-party noise (Meta Pixel, fonts, service worker in test env)
        const text = msg.text();
        const isThirdParty =
          text.includes('facebook') ||
          text.includes('fbq') ||
          text.includes('googleapis') ||
          text.includes('polsia.com/api/beacon') ||
          text.includes('connect.facebook') ||
          text.includes('[SW]') ||
          text.includes('[PWA]');
        if (!isThirdParty) {
          consoleErrors.push(text);
        }
      }
    });

    page.on('pageerror', (error) => {
      consoleErrors.push(`Page error: ${error.message}`);
    });

    await page.goto('/app');

    // Core UI elements load
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('#addTaskBtn')).toBeVisible();
    await expect(page.locator('#taskList')).toBeVisible();

    // Spending column renders
    await expect(page.locator('#budgetRemaining')).toBeAttached();
    await expect(page.locator('#expenseAmount')).toBeVisible();

    // Wait for async data to settle
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {
      // networkidle can timeout on pages with polling — that's fine
    });

    // No critical console errors
    expect(
      consoleErrors,
      `Console errors found:\n${consoleErrors.join('\n')}`
    ).toHaveLength(0);
  });

  test('unauthenticated users are redirected to /login', async ({ page }) => {
    // Use fresh context with no auth
    await page.evaluate(() => localStorage.clear());
    await page.goto('/app');

    // Should redirect to /login
    await page.waitForURL('**/login', { timeout: 10000 });
    await expect(page).toHaveURL(/\/login/);
  });

  test('navigation links work: Settings and Values links present', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    // Settings link in nav
    const settingsLink = page.locator('a[href="/settings"]').first();
    await expect(settingsLink).toBeVisible();

    // Values link in nav
    const valuesLink = page.locator('a[href="/values"]').first();
    await expect(valuesLink).toBeVisible();
  });

  test('spoke navigation cards render on dashboard', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    // Spoke grid should be visible
    await expect(page.locator('#spokeSection')).toBeVisible({ timeout: 10000 });

    // At least 4 spoke cards should render
    const spokeCount = await page.locator('.spoke-card').count();
    expect(spokeCount, 'Expected at least 4 spoke navigation cards').toBeGreaterThanOrEqual(4);
  });
});
