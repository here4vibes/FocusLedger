/**
 * Test 11: /home (Portal / Command Center)
 *
 * Covers:
 *  - Page loads and renders all sections
 *  - Quick-add task form works
 *  - Money Snapshot widget loads
 *  - Calendar widget renders
 *  - Bottom tab bar is visible on mobile and navigates
 *  - Hamburger nav opens on mobile
 *  - No console JS errors on load
 */

const { test, expect } = require('@playwright/test');

test.describe('/home — Command Center', () => {
  test('page loads and shows task list', async ({ page }) => {
    await page.goto('/home');
    // Auth gate redirects if no token — we have auth state, so we land on portal
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });
  });

  test('quick-add task form is present and responds', async ({ page }) => {
    await page.goto('/home');
    await expect(page.locator('#quickAddInput')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('#quickAddBtn')).toBeVisible();

    const taskTitle = `Portal E2E ${Date.now().toString(36)}`;
    await page.fill('#quickAddInput', taskTitle);
    await page.click('#quickAddBtn');

    // Input should clear after submission
    await expect(page.locator('#quickAddInput')).toHaveValue('', { timeout: 5000 });

    // Cleanup via API
    const token = await page.evaluate(() => localStorage.getItem('fl_token'));
    const baseURL = process.env.BASE_URL || 'https://focusledger.polsia.app';
    const listRes = await page.request.get(`${baseURL}/api/tasks`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await listRes.json();
    const created = (data.tasks || []).find(t => t.title === taskTitle);
    if (created) {
      await page.request.delete(`${baseURL}/api/tasks/${created.id}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      }).catch(() => {});
    }
  });

  test('Money Snapshot widget renders', async ({ page }) => {
    await page.goto('/home');
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });
    // Finance section attaches
    await expect(page.locator('#financeLoading, #financeData')).toBeAttached({ timeout: 8000 });
  });

  test('Calendar widget renders', async ({ page }) => {
    await page.goto('/home');
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('#calendarLoading, #calendarData, #calendarEmpty')).toBeAttached({ timeout: 8000 });
  });

  test('bottom tabs visible on mobile and navigate', async ({ page }) => {
    await page.goto('/home');
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });

    // All 5 tab buttons are in DOM
    await expect(page.locator('#tabHome')).toBeAttached();
    await expect(page.locator('#tabTasks')).toBeAttached();
    await expect(page.locator('#tabMoney')).toBeAttached();
    await expect(page.locator('#tabNews')).toBeAttached();
    await expect(page.locator('#tabMore')).toBeAttached();

    // Tasks tab navigates
    await page.locator('#tabTasks').click({ force: false });
    await page.waitForURL('**/app', { timeout: 10000 });
  });

  test('hamburger nav opens on mobile', async ({ page }) => {
    await page.goto('/home');
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });

    const hamburger = page.locator('#portalHamburger');
    if (await hamburger.isVisible()) {
      await hamburger.click({ force: false });
      await expect(page.locator('#portalMobileDropdown')).toHaveClass(/open/, { timeout: 3000 });

      // Close it
      await page.locator('#portalMobileClose').click({ force: false });
      await expect(page.locator('#portalMobileDropdown')).not.toHaveClass(/open/, { timeout: 3000 });
    }
  });

  test('no console JS errors on page load', async ({ page }) => {
    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const t = msg.text();
        if (!t.includes('facebook') && !t.includes('fbq') && !t.includes('[SW]') && !t.includes('polsia.com/api/beacon')) {
          errors.push(t);
        }
      }
    });
    page.on('pageerror', err => errors.push(`Page error: ${err.message}`));

    await page.goto('/home');
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    expect(errors, `Console errors:\n${errors.join('\n')}`).toHaveLength(0);
  });
});
