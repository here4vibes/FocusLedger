/**
 * Test 12: /app — Full Task Management Regression
 *
 * Covers:
 *  - Create task (inline input)
 *  - Edit task title inline
 *  - Complete/toggle task
 *  - Delete task
 *  - Recurring task create/delete toggle
 *  - Breakdown toggle (steps) visible
 *  - Due date toggle
 *  - Bottom tabs present and functional
 *  - Sort by due date button responds
 */

const { test, expect } = require('@playwright/test');

test.describe('/app — Tasks', () => {
  test('create task via input and it appears in list', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    const title = `Regression ${Date.now().toString(36)}`;
    await page.fill('#taskInput', title);
    await page.click('#addTaskBtn');

    await expect(page.locator('#taskList')).toContainText(title, { timeout: 8000 });

    // Clean up
    const token = await page.evaluate(() => localStorage.getItem('fl_token'));
    const baseURL = process.env.BASE_URL || 'https://focusledger.polsia.app';
    const res = await page.request.get(`${baseURL}/api/tasks`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    const task = (data.tasks || []).find(t => t.title === title);
    if (task) {
      await page.request.delete(`${baseURL}/api/tasks/${task.id}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      }).catch(() => {});
    }
  });

  test('task input clears after add', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });
    await page.fill('#taskInput', `ClearTest ${Date.now()}`);
    await page.click('#addTaskBtn');
    await expect(page.locator('#taskInput')).toHaveValue('', { timeout: 5000 });
  });

  test('add task button has adequate touch target (≥44px)', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#addTaskBtn')).toBeVisible({ timeout: 15000 });
    const box = await page.locator('#addTaskBtn').boundingBox();
    expect(box).toBeTruthy();
    expect(box.height, 'Add task button height should be ≥44px').toBeGreaterThanOrEqual(44);
  });

  test('task toggle (complete/uncomplete) works', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    const title = `ToggleTest ${Date.now().toString(36)}`;
    await page.fill('#taskInput', title);
    await page.click('#addTaskBtn');
    await expect(page.locator('#taskList')).toContainText(title, { timeout: 8000 });

    // Click checkbox
    const card = page.locator('.task-card').filter({ hasText: title });
    const checkbox = card.locator('[data-action="toggle-task"]');
    await expect(checkbox).toBeVisible({ timeout: 5000 });
    await checkbox.click({ force: false });

    // Should gain "done" class
    await expect(checkbox).toHaveClass(/done/, { timeout: 5000 });

    // Cleanup
    const token = await page.evaluate(() => localStorage.getItem('fl_token'));
    const baseURL = process.env.BASE_URL || 'https://focusledger.polsia.app';
    const res = await page.request.get(`${baseURL}/api/tasks`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    const task = (data.tasks || []).find(t => t.title === title);
    if (task) {
      await page.request.delete(`${baseURL}/api/tasks/${task.id}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      }).catch(() => {});
    }
  });

  test('task delete button (×) removes task from DOM', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    const title = `DeleteTest ${Date.now().toString(36)}`;
    await page.fill('#taskInput', title);
    await page.click('#addTaskBtn');
    await expect(page.locator('#taskList')).toContainText(title, { timeout: 8000 });

    const card = page.locator('.task-card').filter({ hasText: title });
    const deleteBtn = card.locator('[data-action="delete-task"]');
    await expect(deleteBtn).toBeVisible({ timeout: 5000 });
    await deleteBtn.click({ force: false });

    // Task should disappear from list
    await expect(page.locator('#taskList')).not.toContainText(title, { timeout: 8000 });
  });

  test('breakdown toggle button is present and clickable', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    const toggleTrack = page.locator('#toggleTrack');
    await expect(toggleTrack).toBeVisible({ timeout: 10000 });
    await toggleTrack.click({ force: false });
    // Steps area should toggle visibility — just verify no error thrown
    await page.waitForTimeout(300);
  });

  test('due date toggle link opens date inputs', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#dueDateToggleBtn')).toBeVisible({ timeout: 15000 });
    await page.locator('#dueDateToggleBtn').click({ force: false });
    await expect(page.locator('#dueDateInputsArea')).toBeVisible({ timeout: 3000 });
  });

  test('recurring task toggle button is present', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#repeatToggleBtn')).toBeVisible({ timeout: 15000 });
    await page.locator('#repeatToggleBtn').click({ force: false });
    await expect(page.locator('#repeatOptionsArea')).toBeVisible({ timeout: 3000 });
  });

  test('sort by due date button responds', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#sortDueDateBtn')).toBeVisible({ timeout: 15000 });
    await page.locator('#sortDueDateBtn').click({ force: false });
    // No throw = pass
  });

  test('bottom tabs present on mobile viewport', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('#appBottomTabs')).toBeAttached();
    await expect(page.locator('#tabHome')).toBeAttached();
    await expect(page.locator('#tabTasks')).toBeAttached();
    await expect(page.locator('#tabMoney')).toBeAttached();
    await expect(page.locator('#tabNews')).toBeAttached();
    await expect(page.locator('#tabMore')).toBeAttached();
  });

  test('Settings nav link present', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });
    const settingsLink = page.locator('a[href="/settings"]').first();
    await expect(settingsLink).toBeAttached();
  });
});
