/**
 * Test 14: /calendar — Time Blocking Calendar Regression
 *
 * Covers:
 *  - Page loads calendar grid
 *  - Today button is present and clickable
 *  - Week nav prev/next buttons respond
 *  - Day switcher prev/next works
 *  - Task sidebar/summary renders
 *  - Mobile task toggle button present
 *  - No console errors on load
 */

const { test, expect } = require('@playwright/test');

test.describe('/calendar — Time Blocking Calendar', () => {
  test('page loads calendar grid', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#calGrid')).toBeAttached({ timeout: 15000 });
    await expect(page.locator('#weekLabel')).toBeVisible({ timeout: 10000 });
  });

  test('Today button is present and clickable', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#todayBtn')).toBeVisible({ timeout: 15000 });
    await page.locator('#todayBtn').click({ force: false });
    // No throw + still on /calendar
    await expect(page).toHaveURL(/\/calendar/);
    await expect(page.locator('#weekLabel')).toBeVisible();
  });

  test('prev week button navigates backward', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#weekLabel')).toBeVisible({ timeout: 15000 });
    const before = await page.locator('#weekLabel').textContent();

    await page.locator('#prevWeek').click({ force: false });
    await page.waitForTimeout(300);
    const after = await page.locator('#weekLabel').textContent();
    expect(after).not.toBe(before);
  });

  test('next week button navigates forward', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#weekLabel')).toBeVisible({ timeout: 15000 });
    const before = await page.locator('#weekLabel').textContent();

    await page.locator('#nextWeek').click({ force: false });
    await page.waitForTimeout(300);
    const after = await page.locator('#weekLabel').textContent();
    expect(after).not.toBe(before);
  });

  test('day switcher prev/next buttons present and clickable', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#daySwLabel')).toBeVisible({ timeout: 15000 });

    const before = await page.locator('#daySwLabel').textContent();
    await page.locator('#nextDay').click({ force: false });
    await page.waitForTimeout(300);
    const after = await page.locator('#daySwLabel').textContent();
    expect(after).not.toBe(before);

    await page.locator('#prevDay').click({ force: false });
    await page.waitForTimeout(300);
    const back = await page.locator('#daySwLabel').textContent();
    expect(back).toBe(before);
  });

  test('summary sidebar renders', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#summarySidebar')).toBeAttached({ timeout: 10000 });
    await expect(page.locator('#summaryContent')).toBeAttached();
  });

  test('mobile task toggle button is in DOM', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#mobileTaskToggle')).toBeAttached({ timeout: 10000 });
  });

  test('week nav buttons have adequate touch target (≥44px)', async ({ page }) => {
    await page.goto('/calendar');
    await expect(page.locator('#prevWeek')).toBeVisible({ timeout: 15000 });

    for (const sel of ['#prevWeek', '#nextWeek', '#todayBtn']) {
      const box = await page.locator(sel).boundingBox();
      expect(box, `${sel} should be visible`).toBeTruthy();
      expect(box.height, `${sel} height should be ≥44px`).toBeGreaterThanOrEqual(44);
    }
  });

  test('no console JS errors on page load', async ({ page }) => {
    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const t = msg.text();
        if (!t.includes('facebook') && !t.includes('fbq') && !t.includes('[SW]') && !t.includes('polsia.com/api/beacon')) {
          errors.push(t);
        }
      }
    });
    page.on('pageerror', err => errors.push(`Page error: ${err.message}`));

    await page.goto('/calendar');
    await expect(page.locator('#weekLabel')).toBeVisible({ timeout: 15000 });
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    expect(errors, `Console errors:\n${errors.join('\n')}`).toHaveLength(0);
  });
});
