/**
 * Test 15: /ideas — Ideas Regression
 *
 * Covers:
 *  - Page loads ideas list
 *  - Submit idea form (title input + submit button) works
 *  - Idea count badge renders
 *  - Character count updates as you type
 *  - No console errors on load
 */

const { test, expect } = require('@playwright/test');

test.describe('/ideas — Ideas', () => {
  test('page loads with idea input and submit button', async ({ page }) => {
    await page.goto('/ideas');
    await expect(page.locator('#ideaTitle')).toBeVisible({ timeout: 15000 });
    await expect(page.locator('#submitBtn')).toBeVisible();
  });

  test('idea title input accepts text and shows character count', async ({ page }) => {
    await page.goto('/ideas');
    await expect(page.locator('#ideaTitle')).toBeVisible({ timeout: 15000 });

    await page.fill('#ideaTitle', 'E2E test idea');
    const charCount = page.locator('#titleCount');
    await expect(charCount).toBeVisible();
    const text = await charCount.textContent();
    expect(text).toMatch(/\d+\s*\/\s*200/);
  });

  test('submit button has adequate touch target (≥44px)', async ({ page }) => {
    await page.goto('/ideas');
    await expect(page.locator('#submitBtn')).toBeVisible({ timeout: 15000 });
    const box = await page.locator('#submitBtn').boundingBox();
    expect(box).toBeTruthy();
    expect(box.height, 'Submit button height should be ≥44px').toBeGreaterThanOrEqual(44);
  });

  test('ideas list section renders', async ({ page }) => {
    await page.goto('/ideas');
    await expect(page.locator('#ideasList')).toBeAttached({ timeout: 10000 });
    await expect(page.locator('#ideaCount')).toBeAttached();
  });

  test('submit new idea end-to-end', async ({ page }) => {
    await page.goto('/ideas');
    await expect(page.locator('#ideaTitle')).toBeVisible({ timeout: 15000 });

    const title = `E2E idea ${Date.now().toString(36)}`;
    await page.fill('#ideaTitle', title);
    await page.fill('#ideaDesc', 'Automated regression test idea — safe to ignore');
    await page.click('#submitBtn');

    // After submit, the input should clear or the idea count should increase
    await expect(page.locator('#ideaTitle')).toHaveValue('', { timeout: 8000 });
  });

  test('no console JS errors on page load', async ({ page }) => {
    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const t = msg.text();
        if (!t.includes('facebook') && !t.includes('fbq') && !t.includes('[SW]') && !t.includes('polsia.com/api/beacon')) {
          errors.push(t);
        }
      }
    });
    page.on('pageerror', err => errors.push(`Page error: ${err.message}`));

    await page.goto('/ideas');
    await expect(page.locator('#ideaTitle')).toBeVisible({ timeout: 15000 });
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    expect(errors, `Console errors:\n${errors.join('\n')}`).toHaveLength(0);
  });
});
