/**
 * Test 16: /values — Values Management Regression
 *
 * Covers:
 *  - Page loads
 *  - Add value button is visible and clickable
 *  - Modal opens with name input + save button
 *  - Value name can be typed
 *  - Save button creates a value (modal closes)
 *  - Value appears in list after creation
 *  - Delete value (via API cleanup)
 *  - No console errors on load
 */

const { test, expect } = require('@playwright/test');

test.describe('/values — Values Management', () => {
  test('page loads', async ({ page }) => {
    await page.goto('/values');
    // Values page renders main content
    await expect(page.locator('#mainContent, body')).toBeAttached({ timeout: 15000 });
  });

  test('add value button present and clickable', async ({ page }) => {
    await page.goto('/values');
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    const addBtn = page.locator(
      'button:has-text("Add my first value"), button:has-text("Add another value"), button:has-text("+ Add value"), #addValueBtn, .btn-add-value'
    ).first();

    await expect(addBtn).toBeVisible({ timeout: 10000 });
    await addBtn.click({ force: false });

    // Modal should open
    await expect(page.locator('#valueModal')).toBeVisible({ timeout: 5000 });
  });

  test('value modal has name input and save button', async ({ page }) => {
    await page.goto('/values');
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    const addBtn = page.locator(
      'button:has-text("Add my first value"), button:has-text("Add another value"), button:has-text("+ Add value"), #addValueBtn, .btn-add-value'
    ).first();
    await expect(addBtn).toBeVisible({ timeout: 10000 });
    await addBtn.click({ force: false });

    await expect(page.locator('#inputValueName')).toBeVisible({ timeout: 5000 });
    await expect(page.locator('#saveValueBtn')).toBeVisible();
  });

  test('create a value end-to-end', async ({ page }) => {
    await page.goto('/values');
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    const addBtn = page.locator(
      'button:has-text("Add my first value"), button:has-text("Add another value"), button:has-text("+ Add value"), #addValueBtn, .btn-add-value'
    ).first();
    await expect(addBtn).toBeVisible({ timeout: 10000 });
    await addBtn.click({ force: false });

    await expect(page.locator('#inputValueName')).toBeVisible({ timeout: 5000 });

    const valueName = `E2E Value ${Date.now().toString(36)}`;
    await page.fill('#inputValueName', valueName);
    await page.click('#saveValueBtn');

    // Modal closes after save
    await expect(page.locator('#inputValueName')).not.toBeVisible({ timeout: 8000 });

    // Value name should appear in the list
    await expect(page.locator('.value-name, [class*="value-name"]')).toContainText(valueName, { timeout: 8000 });

    // Cleanup
    const token = await page.evaluate(() => localStorage.getItem('fl_token'));
    const baseURL = process.env.BASE_URL || 'https://focusledger.polsia.app';
    const listRes = await page.request.get(`${baseURL}/api/values`, {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const listData = await listRes.json();
    const testValue = (listData.values || []).find(v => v.value_name === valueName);
    if (testValue) {
      await page.request.delete(`${baseURL}/api/values/${testValue.id}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      }).catch(() => {});
    }
  });

  test('modal close button dismisses modal', async ({ page }) => {
    await page.goto('/values');
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    const addBtn = page.locator(
      'button:has-text("Add my first value"), button:has-text("Add another value"), button:has-text("+ Add value"), #addValueBtn, .btn-add-value'
    ).first();
    await expect(addBtn).toBeVisible({ timeout: 10000 });
    await addBtn.click({ force: false });

    await expect(page.locator('#valueModal')).toBeVisible({ timeout: 5000 });

    await page.locator('#modalClose').click({ force: false });
    await expect(page.locator('#valueModal')).not.toBeVisible({ timeout: 5000 });
  });

  test('save value button has adequate touch target (≥44px)', async ({ page }) => {
    await page.goto('/values');
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    const addBtn = page.locator(
      'button:has-text("Add my first value"), button:has-text("Add another value"), button:has-text("+ Add value"), #addValueBtn, .btn-add-value'
    ).first();
    await expect(addBtn).toBeVisible({ timeout: 10000 });
    await addBtn.click({ force: false });

    const saveBtn = page.locator('#saveValueBtn');
    await expect(saveBtn).toBeVisible({ timeout: 5000 });
    const box = await saveBtn.boundingBox();
    expect(box).toBeTruthy();
    expect(box.height, 'Save Value button should be ≥44px').toBeGreaterThanOrEqual(44);
  });

  test('no console JS errors on page load', async ({ page }) => {
    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const t = msg.text();
        if (!t.includes('facebook') && !t.includes('fbq') && !t.includes('[SW]') && !t.includes('polsia.com/api/beacon')) {
          errors.push(t);
        }
      }
    });
    page.on('pageerror', err => errors.push(`Page error: ${err.message}`));

    await page.goto('/values');
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    expect(errors, `Console errors:\n${errors.join('\n')}`).toHaveLength(0);
  });
});
