/**
 * Test 17: /admin/stats — Admin Dashboard Regression
 *
 * Covers:
 *  - Admin page loads (non-admins should redirect or see limited view)
 *  - Tab buttons (Stats, Users, Analytics) are present and clickable
 *  - Tab content panels switch correctly on click
 *  - Refresh button is present and tappable
 *  - No console errors on load
 *
 * Note: The e2e test user may not be an admin. Tests are structured to
 * check for element presence and basic interactivity, not admin-only data.
 */

const { test, expect } = require('@playwright/test');

test.describe('/admin/stats — Admin Dashboard', () => {
  test('admin page serves without 500 error', async ({ page }) => {
    const response = await page.goto('/admin/stats');
    // Should return 200 (HTML page) — auth check is client-side
    expect(response.status()).toBe(200);
  });

  test('tab buttons are in DOM', async ({ page }) => {
    await page.goto('/admin/stats');
    await expect(page.locator('#tab-stats')).toBeAttached({ timeout: 10000 });
    await expect(page.locator('#tab-users')).toBeAttached();
    await expect(page.locator('#tab-analytics')).toBeAttached();
  });

  test('tab buttons respond to clicks (no z-index block)', async ({ page }) => {
    await page.goto('/admin/stats');
    await expect(page.locator('#tab-stats')).toBeVisible({ timeout: 10000 });

    // Click Users tab
    await page.locator('#tab-users').click({ force: false });
    await page.waitForTimeout(300);

    // Users panel should become visible
    await expect(page.locator('#panel-users')).toBeVisible({ timeout: 3000 });
    await expect(page.locator('#panel-stats')).not.toBeVisible({ timeout: 3000 });
  });

  test('analytics tab switches content', async ({ page }) => {
    await page.goto('/admin/stats');
    await expect(page.locator('#tab-analytics')).toBeVisible({ timeout: 10000 });

    await page.locator('#tab-analytics').click({ force: false });
    await page.waitForTimeout(300);

    await expect(page.locator('#panel-analytics')).toBeVisible({ timeout: 3000 });
    await expect(page.locator('#panel-stats')).not.toBeVisible({ timeout: 3000 });
  });

  test('stats tab restores stats panel', async ({ page }) => {
    await page.goto('/admin/stats');
    await expect(page.locator('#tab-users')).toBeVisible({ timeout: 10000 });

    // Switch away then back
    await page.locator('#tab-users').click({ force: false });
    await page.locator('#tab-stats').click({ force: false });
    await page.waitForTimeout(300);

    await expect(page.locator('#panel-stats')).toBeVisible({ timeout: 3000 });
  });

  test('refresh button is present', async ({ page }) => {
    await page.goto('/admin/stats');
    await expect(page.locator('#btn-refresh')).toBeAttached({ timeout: 10000 });
  });

  test('tab buttons have adequate touch target (≥44px)', async ({ page }) => {
    await page.goto('/admin/stats');
    await expect(page.locator('#tab-stats')).toBeVisible({ timeout: 10000 });

    for (const sel of ['#tab-stats', '#tab-users', '#tab-analytics']) {
      const box = await page.locator(sel).boundingBox();
      expect(box, `${sel} should be visible`).toBeTruthy();
      expect(box.height, `${sel} should be ≥44px`).toBeGreaterThanOrEqual(44);
    }
  });

  test('no console JS errors on page load', async ({ page }) => {
    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const t = msg.text();
        if (!t.includes('facebook') && !t.includes('fbq') && !t.includes('[SW]') && !t.includes('polsia.com/api/beacon')) {
          errors.push(t);
        }
      }
    });
    page.on('pageerror', err => errors.push(`Page error: ${err.message}`));

    await page.goto('/admin/stats');
    await expect(page.locator('#tab-stats')).toBeVisible({ timeout: 15000 });
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    expect(errors, `Console errors:\n${errors.join('\n')}`).toHaveLength(0);
  });
});
