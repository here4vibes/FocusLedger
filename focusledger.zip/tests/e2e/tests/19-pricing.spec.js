/**
 * Test 19: /pricing — Pricing Page Regression
 *
 * Covers (expanded from test 08):
 *  - Pricing page renders with all plan cards
 *  - Monthly/annual billing toggle switches pricing
 *  - Pro upgrade button links to Stripe (not dead)
 *  - Sign Up CTA buttons for free plan route to /signup
 *  - Pricing amounts display (not blank/zero)
 *  - No console errors on load
 */

const { test, expect } = require('@playwright/test');

// Pricing page is public — use fresh (no auth) state to test as a logged-out visitor
test.use({ storageState: { cookies: [], origins: [] } });

test.describe('/pricing — Pricing Page', () => {
  test('page loads with Pro plan visible', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#proBtn')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('text=Pro')).toBeVisible();
  });

  test('pricing amounts display (not empty)', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#proPriceAmount')).toBeVisible({ timeout: 10000 });
    const amount = await page.locator('#proPriceAmount').textContent();
    expect(amount?.trim(), 'Pro price amount should not be empty').toBeTruthy();
    expect(amount?.trim(), 'Pro price amount should not be zero').not.toBe('0');
  });

  test('Pro upgrade button has a valid Stripe href', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#proBtn')).toBeVisible({ timeout: 10000 });

    const href = await page.locator('#proBtn').getAttribute('href');
    expect(href, 'Pro button href should not be null').toBeTruthy();
    expect(href, 'Pro button should not be a dead link (#)').not.toBe('#');
    expect(href, 'Pro button should link to Stripe').toMatch(/stripe\.com|stripecdn\.com/i);
  });

  test('billing toggle switches between monthly and annual pricing', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#proBtn')).toBeVisible({ timeout: 10000 });

    const priceEl = page.locator('#proPriceAmount');
    const monthlyAmount = await priceEl.textContent();

    const annualLabel = page.locator('#annualLabel');
    if (await annualLabel.isVisible()) {
      await annualLabel.click({ force: false });
      const annualAmount = await priceEl.textContent();
      expect(annualAmount, 'Annual price should differ from monthly price').not.toBe(monthlyAmount);
    }
  });

  test('billing switch (toggle track) is clickable', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#billingSwitch')).toBeVisible({ timeout: 10000 });
    await page.locator('#billingSwitch').click({ force: false });
    // No error = pass
  });

  test('Pro upgrade button has adequate touch target (≥44px)', async ({ page }) => {
    await page.goto('/pricing');
    await expect(page.locator('#proBtn')).toBeVisible({ timeout: 10000 });
    const box = await page.locator('#proBtn').boundingBox();
    expect(box).toBeTruthy();
    expect(box.height, 'Upgrade button height should be ≥44px').toBeGreaterThanOrEqual(44);
  });

  test('no console JS errors on page load', async ({ page }) => {
    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        const t = msg.text();
        if (!t.includes('facebook') && !t.includes('fbq') && !t.includes('[SW]') && !t.includes('polsia.com/api/beacon')) {
          errors.push(t);
        }
      }
    });
    page.on('pageerror', err => errors.push(`Page error: ${err.message}`));

    await page.goto('/pricing');
    await expect(page.locator('#proBtn')).toBeVisible({ timeout: 10000 });
    await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

    expect(errors, `Console errors:\n${errors.join('\n')}`).toHaveLength(0);
  });
});
