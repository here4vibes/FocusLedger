/**
 * Test 20: Shared / Cross-Page Regression Checks
 *
 * Covers every page for:
 *  - Bottom tab bar visible on mobile viewport (375px)
 *  - Every bottom tab navigates to correct route
 *  - Logo / app name links to /home (logged in) or / (logged out)
 *  - No 404 on critical page routes
 *  - All buttons have minimum 44px touch target (spot-check key pages)
 *  - No z-index overlay blocking interactive elements (force:false click actionability)
 */

const { test, expect } = require('@playwright/test');

// Pages to check for bottom tabs + console errors
const AUTHED_PAGES = [
  { path: '/home', anchor: '#taskList' },
  { path: '/app', anchor: '#taskInput' },
  { path: '/settings', anchor: 'h1' },
  { path: '/calendar', anchor: '#weekLabel' },
  { path: '/ideas', anchor: '#ideaTitle' },
  { path: '/values', anchor: 'body' },
];

// Public pages — must return 200
const PUBLIC_ROUTES = ['/', '/login', '/signup', '/pricing', '/terms', '/privacy'];

test.describe('Shared checks — all pages', () => {
  // ── Public route availability ───────────────────────────────────────────────
  for (const route of PUBLIC_ROUTES) {
    test(`${route} returns HTTP 200`, async ({ page }) => {
      const response = await page.goto(route);
      expect(response?.status(), `${route} should return 200`).toBe(200);
    });
  }

  // ── Authenticated page availability ────────────────────────────────────────
  for (const { path, anchor } of AUTHED_PAGES) {
    test(`${path} returns HTTP 200`, async ({ page }) => {
      const response = await page.goto(path);
      expect(response?.status(), `${path} should return 200`).toBe(200);
    });

    test(`${path} renders without uncaught JS errors`, async ({ page }) => {
      const errors = [];
      page.on('console', msg => {
        if (msg.type() === 'error') {
          const t = msg.text();
          if (!t.includes('facebook') && !t.includes('fbq') && !t.includes('[SW]') && !t.includes('polsia.com/api/beacon')) {
            errors.push(t);
          }
        }
      });
      page.on('pageerror', err => errors.push(`Page error: ${err.message}`));

      await page.goto(path);
      await expect(page.locator(anchor)).toBeAttached({ timeout: 15000 });
      await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});

      expect(errors, `Console errors on ${path}:\n${errors.join('\n')}`).toHaveLength(0);
    });
  }

  // ── Bottom tabs on /app ─────────────────────────────────────────────────────
  test('/app bottom tabs: all 5 present in DOM', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    for (const tabId of ['#tabHome', '#tabTasks', '#tabMoney', '#tabNews', '#tabMore']) {
      await expect(page.locator(tabId), `${tabId} should be in DOM`).toBeAttached();
    }
  });

  test('/app bottom tab Home navigates to /home', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    await page.locator('#tabHome').click({ force: false });
    await page.waitForURL('**/home', { timeout: 10000 });
    await expect(page).toHaveURL(/\/home/);
  });

  test('/app bottom tab Money navigates to /money or /app#expenses', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    await page.locator('#tabMoney').click({ force: false });
    await page.waitForURL(/\/money|\/app/, { timeout: 10000 });
    // /money redirects to /app#expenses — either URL is correct
    expect(page.url()).toMatch(/\/money|\/app/);
  });

  test('/app bottom tab More navigates to /settings', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    await page.locator('#tabMore').click({ force: false });
    await page.waitForURL('**/settings', { timeout: 10000 });
    await expect(page).toHaveURL(/\/settings/);
  });

  // ── Bottom tabs on /home ────────────────────────────────────────────────────
  test('/home bottom tabs: all 5 present in DOM', async ({ page }) => {
    await page.goto('/home');
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });

    for (const tabId of ['#tabHome', '#tabTasks', '#tabMoney', '#tabNews', '#tabMore']) {
      await expect(page.locator(tabId), `${tabId} should be in DOM`).toBeAttached();
    }
  });

  test('/home bottom tab Tasks navigates to /app', async ({ page }) => {
    await page.goto('/home');
    await expect(page.locator('#taskList')).toBeVisible({ timeout: 15000 });

    await page.locator('#tabTasks').click({ force: false });
    await page.waitForURL('**/app', { timeout: 10000 });
    await expect(page).toHaveURL(/\/app/);
  });

  // ── Auth redirect ───────────────────────────────────────────────────────────
  test('unauthenticated user is redirected from /app to /login', async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: { cookies: [], origins: [] } });
    const page = await ctx.newPage();

    await page.goto('/app');
    await page.waitForURL(/\/login/, { timeout: 10000 });
    expect(page.url()).toMatch(/\/login/);

    await ctx.close();
  });

  // ── Touch target spot-check ─────────────────────────────────────────────────
  test('/app: key buttons have ≥44px touch target', async ({ page }) => {
    await page.goto('/app');
    await expect(page.locator('#taskInput')).toBeVisible({ timeout: 15000 });

    const selectors = ['#addTaskBtn', '#addExpenseBtn'];
    for (const sel of selectors) {
      const el = page.locator(sel);
      if (await el.isVisible()) {
        const box = await el.boundingBox();
        expect(box, `${sel} should be visible`).toBeTruthy();
        expect(box.height, `${sel} should have ≥44px height`).toBeGreaterThanOrEqual(44);
      }
    }
  });

  test('/settings: key buttons have ≥44px touch target', async ({ page }) => {
    await page.goto('/settings');
    await expect(page.locator('#saveDisplayNameBtn')).toBeVisible({ timeout: 10000 });
    const box = await page.locator('#saveDisplayNameBtn').boundingBox();
    expect(box).toBeTruthy();
    expect(box.height, 'Save display name button should be ≥44px').toBeGreaterThanOrEqual(44);
  });

  // ── /login page ─────────────────────────────────────────────────────────────
  test('/login form has email, password, submit button', async ({ page }) => {
    await page.goto('/login');
    await expect(page.locator('#email')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('#password')).toBeVisible();
    await expect(page.locator('#submitBtn')).toBeVisible();
  });

  // ── /signup page ────────────────────────────────────────────────────────────
  test('/signup form has name, email, password, submit button', async ({ page }) => {
    await page.goto('/signup');
    await expect(page.locator('#email')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('#password')).toBeVisible();
    await expect(page.locator('#submitBtn')).toBeVisible();
  });
});
