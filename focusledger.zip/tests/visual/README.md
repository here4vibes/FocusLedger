# Visual Regression Tests

Screenshot-based regression testing that catches layout issues the interaction tests miss.

## What It Catches

- **Dead buttons** — elements that exist in the DOM but are visually obscured by z-index overlaps (Connect Gmail, Plaid, etc.)
- **CSS layout drift** — spacing, sizing, or positioning changes between deploys
- **Missing elements** — a section or component that stopped rendering
- **Broken mobile layouts** — overflow, cut-off content, elements off-screen
- **Unexpected visual changes** — anything that looks different from the approved baseline

## Pages Covered

| Page | Route | Auth Required |
|------|-------|--------------|
| Landing / Home | `/` | No |
| Login | `/login` | No |
| Signup | `/signup` | No |
| Pricing | `/pricing` | No |
| App / Dashboard | `/app` | Yes |
| Portal / Home | `/home` | Yes |
| Settings | `/settings` | Yes |
| Calendar | `/calendar` | Yes |
| Ideas | `/ideas` | Yes |
| Values | `/values` | Yes |
| Email inbox | `/email` | Yes |
| Spending tracker | `/app` (scrolled to expenses) | Yes |
| News | `/news` | Yes |
| Admin stats | `/admin/stats` | Yes (admin only) |

## Viewports

- **Mobile**: 375×812 @ 2x (iPhone SE / smallest common mobile)
- **Desktop**: 1280×900 @ 1x (standard widescreen)

## Threshold

**0.5% of page pixels** can differ before a test fails. This is tight enough to catch layout drift while tolerating minor anti-aliasing differences across OS/browser versions.

## Running Locally

```bash
# First run — generate baseline snapshots
npm run test:visual:update

# Normal run — compare against baselines
npm run test:visual

# Open Playwright UI for debugging
npx playwright test --config=playwright.visual.config.js --ui
```

## Updating Baselines

When a visual change is **intentional** (design update, new feature):

1. Review the diff in the HTML report (`visual-report/`)
2. If the change looks correct, update baselines:
   ```bash
   npm run test:visual:update
   ```
3. Commit the updated snapshots:
   ```bash
   git add tests/visual/snapshots/
   git commit -m "chore: update visual regression baselines for [feature name]"
   ```

In CI, trigger a manual run of the **Visual Regression** workflow with `update_snapshots=true` — this commits the new baselines automatically.

## Snapshot Storage

Baselines live in `tests/visual/snapshots/` and are committed to the repo.

```
tests/visual/snapshots/
  visual-mobile/          ← 375px screenshots
  visual-desktop/         ← 1280px screenshots
```

## CI Integration

The **Visual Regression** workflow (`.github/workflows/visual-regression.yml`) runs on every push to `main` and every PR. Diffs are uploaded as GitHub Actions artifacts (`visual-regression-report`, `visual-regression-diffs`) for 14 days.
