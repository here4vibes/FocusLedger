/**
 * Visual Regression Screenshot Tests
 *
 * Captures full-page screenshots of every key FocusLedger page at mobile (375px)
 * and desktop (1280px) and compares against stored baselines.
 *
 * Threshold: 0.5% pixel difference (config: playwright.visual.config.js)
 *
 * Catches:
 *   - z-index overlaps hiding buttons (the recurring "dead button" pattern)
 *   - CSS layout drift between deploys
 *   - Missing elements (section vanished, component not rendered)
 *   - Broken mobile layouts (overflow, cut-off content)
 *   - Elements rendered off-screen
 *
 * Baseline management:
 *   First run (no baselines):  npx playwright test --config=playwright.visual.config.js --update-snapshots
 *   Update after approved UI:  npx playwright test --config=playwright.visual.config.js --update-snapshots
 *   CI comparison (default):   npx playwright test --config=playwright.visual.config.js
 */

const { test, expect } = require('@playwright/test');

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Wait for the page to be visually stable:
 *  - network idle (or timeout gracefully — polling pages won't reach idle)
 *  - no CSS animations running
 *  - fonts loaded
 */
async function waitForStable(page, timeout = 10000) {
  await page.waitForLoadState('domcontentloaded');
  try {
    await page.waitForLoadState('networkidle', { timeout });
  } catch {
    // OK — pages with background polling never fully idle
  }
  // Give any CSS transitions a moment to settle
  await page.waitForTimeout(500);
}

/**
 * Hide dynamic/volatile content that changes every render:
 *  - timestamps, dates, greeting lines ("Good morning, …")
 *  - chart canvases (data-driven, changes with real data)
 *  - avatar initials derived from user name
 *  - ad slot iframes
 */
async function maskVolatileContent(page) {
  await page.addStyleTag({
    content: `
      /* Timestamps and date labels */
      [data-testid="timestamp"],
      .timestamp, .date-label, .time-label,
      time,
      /* Greeting banners */
      .greeting, #greetingText, [class*="greeting"],
      /* Chart canvases — pixel data changes every render */
      canvas,
      /* Placeholder skeleton loaders — only if still visible after networkidle */
      .skeleton, [class*="skeleton"],
      /* Ads / third-party iframes */
      iframe
      {
        visibility: hidden !important;
      }
    `,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Public pages (no auth required)
// ─────────────────────────────────────────────────────────────────────────────

test.describe('Public pages', () => {
  // Use fresh context — no auth cookie — for public pages
  test.use({ storageState: { cookies: [], origins: [] } });

  test('home / landing page', async ({ page }, testInfo) => {
    await page.goto('/');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`home-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('login page', async ({ page }, testInfo) => {
    await page.goto('/login');
    await waitForStable(page);

    await expect(page).toHaveScreenshot(`login-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('signup page', async ({ page }, testInfo) => {
    await page.goto('/signup');
    await waitForStable(page);

    await expect(page).toHaveScreenshot(`signup-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('pricing page', async ({ page }, testInfo) => {
    await page.goto('/pricing');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`pricing-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Authenticated pages
// ─────────────────────────────────────────────────────────────────────────────

test.describe('Authenticated pages', () => {
  test('main app / dashboard (/app)', async ({ page }, testInfo) => {
    await page.goto('/app');
    // Wait for the core task input — confirms app is hydrated
    await page.waitForSelector('#taskInput', { timeout: 15000 }).catch(() => {});
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`app-dashboard-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('home / portal', async ({ page }, testInfo) => {
    await page.goto('/home');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`home-portal-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('settings page', async ({ page }, testInfo) => {
    await page.goto('/settings');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`settings-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('calendar page', async ({ page }, testInfo) => {
    await page.goto('/calendar');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`calendar-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('ideas page', async ({ page }, testInfo) => {
    await page.goto('/ideas');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`ideas-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('values page', async ({ page }, testInfo) => {
    await page.goto('/values');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`values-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('email / inbox page', async ({ page }, testInfo) => {
    await page.goto('/email');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`email-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('spending tracker (app#expenses)', async ({ page }, testInfo) => {
    await page.goto('/app');
    // Scroll to expenses section or navigate to it
    await page.waitForSelector('#taskInput', { timeout: 15000 }).catch(() => {});
    await waitForStable(page);
    // Try to scroll to the expenses panel
    const expenseSection = page.locator('#expenseAmount, #budgetRemaining').first();
    if (await expenseSection.isVisible()) {
      await expenseSection.scrollIntoViewIfNeeded();
    }
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`spending-tracker-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('news page', async ({ page }, testInfo) => {
    await page.goto('/news');
    await waitForStable(page);
    await maskVolatileContent(page);

    await expect(page).toHaveScreenshot(`news-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });

  test('admin stats page', async ({ page }, testInfo) => {
    await page.goto('/admin/stats');
    await waitForStable(page);
    await maskVolatileContent(page);

    // Admin page may redirect if not admin — capture whatever renders
    await expect(page).toHaveScreenshot(`admin-stats-${testInfo.project.name}.png`, {
      fullPage: true,
    });
  });
});
