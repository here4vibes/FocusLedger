// Global type augmentations for FocusLedger Express server
// These bridge the gap between TypeScript's Express types and our runtime usage

import 'express';

declare global {
  namespace Express {
    interface Request {
      /** Decoded JWT payload — set by authenticateToken middleware */
      user?: {
        id: number | string;
        email: string;
        name?: string | null;
        iat?: number;
        exp?: number;
      };
    }
  }
}

export {};
